import FWCore.ParameterSet.Config as cms

process = cms.Process("FLASHggSyst")

process.source = cms.Source("PoolSource",
    fileNames = cms.untracked.vstring(
        'root://cms-xrd-global.cern.ch//store/user/alesauva/flashgg/UL2017_test/10_6_4/DoubleEG/UL_test-10_6_4-v0-Run2017B-09Aug2019_UL2017-v1/200814_075626/0002/myMicroAODOutputFile_2193.root', 
        'root://cms-xrd-global.cern.ch//store/user/alesauva/flashgg/UL2017_test/10_6_4/DoubleEG/UL_test-10_6_4-v0-Run2017B-09Aug2019_UL2017-v1/200814_075626/0002/myMicroAODOutputFile_2028.root'
    ),
    lumisToSkip = cms.untracked.VLuminosityBlockRange()
)
process.CondDB = cms.PSet(
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        messageLevel = cms.untracked.int32(0),
        security = cms.untracked.string('')
    ),
    connect = cms.string('')
)

process.FNUFBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.00062),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.00208),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(5e-05),
            upBounds = cms.vdouble(6.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.00227),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.FNUFEB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.00062),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.00208),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(5e-05),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.00227),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FNUFEB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.FNUFEE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.00062),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.00208),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(5e-05),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.00227),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FNUFEE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.FracRVNvtxWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(-0.5),
                uncertainties = cms.vdouble(0.00155068, 0.00155068, 0.00918045, 0.00918045),
                upBounds = cms.vdouble(10.5),
                values = cms.vdouble(1.02898, 0.828452)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(10.5),
                uncertainties = cms.vdouble(0.0013211, 0.0013211, 0.00679271, 0.00679271),
                upBounds = cms.vdouble(12.5),
                values = cms.vdouble(1.00775, 0.960156)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(12.5),
                uncertainties = cms.vdouble(0.00113947, 0.00113947, 0.00535269, 0.00535269),
                upBounds = cms.vdouble(14.5),
                values = cms.vdouble(1.00406, 0.980929)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(14.5),
                uncertainties = cms.vdouble(0.00109956, 0.00109956, 0.00493888, 0.00493888),
                upBounds = cms.vdouble(16.5),
                values = cms.vdouble(1.00159, 0.992869)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(16.5),
                uncertainties = cms.vdouble(0.00112887, 0.00112887, 0.00481407, 0.00481407),
                upBounds = cms.vdouble(18.5),
                values = cms.vdouble(0.993201, 1.02899)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(18.5),
                uncertainties = cms.vdouble(0.0012414, 0.0012414, 0.00502105, 0.00502105),
                upBounds = cms.vdouble(20.5),
                values = cms.vdouble(0.991425, 1.03468)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(20.5),
                uncertainties = cms.vdouble(0.00142369, 0.00142369, 0.00545553, 0.00545553),
                upBounds = cms.vdouble(22.5),
                values = cms.vdouble(0.989716, 1.03941)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(22.5),
                uncertainties = cms.vdouble(0.00147513, 0.00147513, 0.00538112, 0.00538112),
                upBounds = cms.vdouble(25.5),
                values = cms.vdouble(0.98674, 1.04837)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(25.5),
                uncertainties = cms.vdouble(0.00188024, 0.00188024, 0.00643049, 0.00643049),
                upBounds = cms.vdouble(30.5),
                values = cms.vdouble(0.976922, 1.07893)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(30.5),
                uncertainties = cms.vdouble(0.00440431, 0.00440431, 0.0142389, 0.0142389),
                upBounds = cms.vdouble(100.5),
                values = cms.vdouble(0.959731, 1.13018)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(100.5),
                uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
                upBounds = cms.vdouble(999999999),
                values = cms.vdouble(1, 1)
            )
        ),
        variables = cms.vstring('nVert')
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FracRVNvtxWeight'),
    MethodName = cms.string('FlashggDiPhotonWeightFromFracRV'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('nVert<99999')
)

process.FracRVWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0),
                uncertainties = cms.vdouble(0.0296904, 0.0296904, 0.0310986, 0.0310986),
                upBounds = cms.vdouble(5),
                values = cms.vdouble(0.958392, 1.04357)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(5),
                uncertainties = cms.vdouble(0.0309958, 0.0309958, 0.0352084, 0.0352084),
                upBounds = cms.vdouble(10),
                values = cms.vdouble(0.977373, 1.0257)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(10),
                uncertainties = cms.vdouble(0.0296353, 0.0296353, 0.0410014, 0.0410014),
                upBounds = cms.vdouble(15),
                values = cms.vdouble(0.974783, 1.03489)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(15),
                uncertainties = cms.vdouble(0.0251379, 0.0251379, 0.0438491, 0.0438491),
                upBounds = cms.vdouble(20),
                values = cms.vdouble(0.970213, 1.05195)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(20),
                uncertainties = cms.vdouble(0.017448, 0.017448, 0.0451307, 0.0451307),
                upBounds = cms.vdouble(30),
                values = cms.vdouble(0.972045, 1.0723)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(30),
                uncertainties = cms.vdouble(0.0118301, 0.0118301, 0.0510668, 0.0510668),
                upBounds = cms.vdouble(40),
                values = cms.vdouble(0.984069, 1.06876)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(40),
                uncertainties = cms.vdouble(0.00743091, 0.00743091, 0.0506721, 0.0506721),
                upBounds = cms.vdouble(50),
                values = cms.vdouble(0.989929, 1.06865)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(50),
                uncertainties = cms.vdouble(0.00536046, 0.00536046, 0.0538791, 0.0538791),
                upBounds = cms.vdouble(60),
                values = cms.vdouble(0.992927, 1.07105)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(60),
                uncertainties = cms.vdouble(0.00313061, 0.00313061, 0.0474004, 0.0474004),
                upBounds = cms.vdouble(80),
                values = cms.vdouble(0.995524, 1.06772)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(80),
                uncertainties = cms.vdouble(0.00184726, 0.00184726, 0.0405967, 0.0405967),
                upBounds = cms.vdouble(100),
                values = cms.vdouble(0.997446, 1.05604)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(100),
                uncertainties = cms.vdouble(0.00119552, 0.00119552, 0.0411651, 0.0411651),
                upBounds = cms.vdouble(140),
                values = cms.vdouble(0.999115, 1.03045)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(140),
                uncertainties = cms.vdouble(0.000725067, 0.000725067, 0.0555666, 0.0555666),
                upBounds = cms.vdouble(200),
                values = cms.vdouble(0.99973, 1.02064)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(200),
                uncertainties = cms.vdouble(0.000959052, 0.000959052, 0.216813, 0.216813),
                upBounds = cms.vdouble(400),
                values = cms.vdouble(0.998152, 1.38258)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(400),
                uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
                upBounds = cms.vdouble(999999999),
                values = cms.vdouble(1, 1)
            )
        ),
        variables = cms.vstring('pt')
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FracRVWeight'),
    MethodName = cms.string('FlashggDiPhotonWeightFromFracRV'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('pt<99999')
)

process.HFRecalParameterBlock = cms.PSet(
    HFdepthOneParameterA = cms.vdouble(
        0.004123, 0.00602, 0.008201, 0.010489, 0.013379, 
        0.016997, 0.021464, 0.027371, 0.034195, 0.044807, 
        0.058939, 0.125497
    ),
    HFdepthOneParameterB = cms.vdouble(
        -4e-06, -2e-06, 0.0, 4e-06, 1.5e-05, 
        2.6e-05, 6.3e-05, 8.4e-05, 0.00016, 0.000107, 
        0.000425, 0.000209
    ),
    HFdepthTwoParameterA = cms.vdouble(
        0.002861, 0.004168, 0.0064, 0.008388, 0.011601, 
        0.014425, 0.018633, 0.023232, 0.028274, 0.035447, 
        0.051579, 0.086593
    ),
    HFdepthTwoParameterB = cms.vdouble(
        -2e-06, -0.0, -7e-06, -6e-06, -2e-06, 
        1e-06, 1.9e-05, 3.1e-05, 6.7e-05, 1.2e-05, 
        0.000157, -3e-06
    )
)

process.HTXSInputTags = cms.PSet(
    ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
    njets = cms.InputTag("rivetProducerHTXS","njets"),
    pTH = cms.InputTag("rivetProducerHTXS","pTH"),
    pTV = cms.InputTag("rivetProducerHTXS","pTV"),
    stage0bin = cms.InputTag("rivetProducerHTXS","stage0bin"),
    stage1bin = cms.InputTag("rivetProducerHTXS","stage1bin")
)

process.LooseMvaSF = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.0014),
                upBounds = cms.vdouble(1.5, 0.85),
                values = cms.vdouble(1.0021)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85),
                uncertainties = cms.vdouble(0.0038),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(1.0001)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0014),
                upBounds = cms.vdouble(6.0, 0.9),
                values = cms.vdouble(1.0061)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9),
                uncertainties = cms.vdouble(0.0023),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(1.0016)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('LooseMvaSF'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.MCScaleGain1EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleGain1EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('hasSwitchToGain1&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('100')
)

process.MCScaleGain6EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleGain6EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('hasSwitchToGain6&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('100')
)

process.MCScaleHighR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleHighR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(),
    OverallRange = cms.string('full5x5_r9>0.96&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCScaleHighR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleHighR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(),
    OverallRange = cms.string('full5x5_r9>0.96&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCScaleLowR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleLowR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(),
    OverallRange = cms.string('full5x5_r9<0.96&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCScaleLowR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleLowR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(),
    OverallRange = cms.string('full5x5_r9<0.96&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCSmearHighR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearHighR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9>0.96&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MCSmearHighR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearHighR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9>0.96&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MCSmearLowR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearLowR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9<=0.96&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MCSmearLowR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearLowR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9<=0.96&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MaterialCentralBarrel = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.000455),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.000233),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.00109),
                upBounds = cms.vdouble(999.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.002377),
                upBounds = cms.vdouble(999.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MaterialCentralBarrel'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)<1.0 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MaterialForward = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.000455),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.000233),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.00109),
                upBounds = cms.vdouble(999.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.002377),
                upBounds = cms.vdouble(999.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MaterialForward'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MaterialOuterBarrel = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.000455),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.000233),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.00109),
                upBounds = cms.vdouble(999.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.002377),
                upBounds = cms.vdouble(999.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MaterialOuterBarrel'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)>=1.0&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MvaShift = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(cms.PSet(
            lowBounds = cms.vdouble(0.0),
            uncertainties = cms.vdouble(0.0),
            upBounds = cms.vdouble(999.0),
            values = cms.vdouble(0.0)
        )),
        variables = cms.vstring('abs(superCluster.eta)')
    ),
    CorrectionFile = cms.FileInPath('flashgg/Systematics/data/SystematicsIDMVA_LegRunII_v1_UL2017.root'),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MvaShift'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonMvaTransform')
)

process.PixelSeedWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.00401807),
                upBounds = cms.vdouble(1.5, 0.85, 0.1),
                values = cms.vdouble(0.978)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, -0.1),
                uncertainties = cms.vdouble(-0.00200421),
                upBounds = cms.vdouble(1.5, 999.0, 0.1),
                values = cms.vdouble(0.9824)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.0224756),
                upBounds = cms.vdouble(6.0, 0.9, 0.1),
                values = cms.vdouble(0.9168)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, -0.1),
                uncertainties = cms.vdouble(-0.00631264),
                upBounds = cms.vdouble(6.0, 999.0, 0.1),
                values = cms.vdouble(0.9403)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0162106),
                upBounds = cms.vdouble(1.5, 0.85, 1.1),
                values = cms.vdouble(1.08876)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, 0.9),
                uncertainties = cms.vdouble(0.0678807),
                upBounds = cms.vdouble(1.5, 999.0, 1.1),
                values = cms.vdouble(1.5961)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0263745),
                upBounds = cms.vdouble(6.0, 0.9, 1.1),
                values = cms.vdouble(1.09763)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, 0.9),
                uncertainties = cms.vdouble(0.0214274),
                upBounds = cms.vdouble(6.0, 999.0, 1.1),
                values = cms.vdouble(1.20264)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9', 
            'hasPixelSeed'
        )
    ),
    BinList2 = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.00415083),
                upBounds = cms.vdouble(1.5, 0.85, 0.1),
                values = cms.vdouble(0.978)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, -0.1),
                uncertainties = cms.vdouble(-0.00280026),
                upBounds = cms.vdouble(1.5, 999.0, 0.1),
                values = cms.vdouble(0.9824)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.0225538),
                upBounds = cms.vdouble(6.0, 0.9, 0.1),
                values = cms.vdouble(0.9168)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, -0.1),
                uncertainties = cms.vdouble(-0.00655045),
                upBounds = cms.vdouble(6.0, 999.0, 0.1),
                values = cms.vdouble(0.9403)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0248967),
                upBounds = cms.vdouble(1.5, 0.85, 1.1),
                values = cms.vdouble(1.13196)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, 0.9),
                uncertainties = cms.vdouble(0.0978689),
                upBounds = cms.vdouble(1.5, 999.0, 1.1),
                values = cms.vdouble(1.61512)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0287957),
                upBounds = cms.vdouble(6.0, 0.9, 1.1),
                values = cms.vdouble(1.10623)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, 0.9),
                uncertainties = cms.vdouble(0.0222861),
                upBounds = cms.vdouble(6.0, 999.0, 1.1),
                values = cms.vdouble(1.20311)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9', 
            'hasPixelSeed'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('PixelSeedWeight'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('pt<99999'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.PreselSF = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.0307),
                upBounds = cms.vdouble(1.5, 0.85),
                values = cms.vdouble(0.9961)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85),
                uncertainties = cms.vdouble(0.0057),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.9981)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0129),
                upBounds = cms.vdouble(6.0, 0.9),
                values = cms.vdouble(1.0054)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9),
                uncertainties = cms.vdouble(0.0018),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(1.0061)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('PreselSF'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.RVBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0),
            uncertainties = cms.vdouble(0.0296904, 0.0296904, 0.0310986, 0.0310986),
            upBounds = cms.vdouble(5),
            values = cms.vdouble(0.958392, 1.04357)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(5),
            uncertainties = cms.vdouble(0.0309958, 0.0309958, 0.0352084, 0.0352084),
            upBounds = cms.vdouble(10),
            values = cms.vdouble(0.977373, 1.0257)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(10),
            uncertainties = cms.vdouble(0.0296353, 0.0296353, 0.0410014, 0.0410014),
            upBounds = cms.vdouble(15),
            values = cms.vdouble(0.974783, 1.03489)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(15),
            uncertainties = cms.vdouble(0.0251379, 0.0251379, 0.0438491, 0.0438491),
            upBounds = cms.vdouble(20),
            values = cms.vdouble(0.970213, 1.05195)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(20),
            uncertainties = cms.vdouble(0.017448, 0.017448, 0.0451307, 0.0451307),
            upBounds = cms.vdouble(30),
            values = cms.vdouble(0.972045, 1.0723)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(30),
            uncertainties = cms.vdouble(0.0118301, 0.0118301, 0.0510668, 0.0510668),
            upBounds = cms.vdouble(40),
            values = cms.vdouble(0.984069, 1.06876)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(40),
            uncertainties = cms.vdouble(0.00743091, 0.00743091, 0.0506721, 0.0506721),
            upBounds = cms.vdouble(50),
            values = cms.vdouble(0.989929, 1.06865)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(50),
            uncertainties = cms.vdouble(0.00536046, 0.00536046, 0.0538791, 0.0538791),
            upBounds = cms.vdouble(60),
            values = cms.vdouble(0.992927, 1.07105)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(60),
            uncertainties = cms.vdouble(0.00313061, 0.00313061, 0.0474004, 0.0474004),
            upBounds = cms.vdouble(80),
            values = cms.vdouble(0.995524, 1.06772)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(80),
            uncertainties = cms.vdouble(0.00184726, 0.00184726, 0.0405967, 0.0405967),
            upBounds = cms.vdouble(100),
            values = cms.vdouble(0.997446, 1.05604)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(100),
            uncertainties = cms.vdouble(0.00119552, 0.00119552, 0.0411651, 0.0411651),
            upBounds = cms.vdouble(140),
            values = cms.vdouble(0.999115, 1.03045)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(140),
            uncertainties = cms.vdouble(0.000725067, 0.000725067, 0.0555666, 0.0555666),
            upBounds = cms.vdouble(200),
            values = cms.vdouble(0.99973, 1.02064)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(200),
            uncertainties = cms.vdouble(0.000959052, 0.000959052, 0.216813, 0.216813),
            upBounds = cms.vdouble(400),
            values = cms.vdouble(0.998152, 1.38258)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(400),
            uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
            upBounds = cms.vdouble(999999999),
            values = cms.vdouble(1, 1)
        )
    ),
    variables = cms.vstring('pt')
)

process.RVBinsNvtx = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(-0.5),
            uncertainties = cms.vdouble(0.00155068, 0.00155068, 0.00918045, 0.00918045),
            upBounds = cms.vdouble(10.5),
            values = cms.vdouble(1.02898, 0.828452)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(10.5),
            uncertainties = cms.vdouble(0.0013211, 0.0013211, 0.00679271, 0.00679271),
            upBounds = cms.vdouble(12.5),
            values = cms.vdouble(1.00775, 0.960156)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(12.5),
            uncertainties = cms.vdouble(0.00113947, 0.00113947, 0.00535269, 0.00535269),
            upBounds = cms.vdouble(14.5),
            values = cms.vdouble(1.00406, 0.980929)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(14.5),
            uncertainties = cms.vdouble(0.00109956, 0.00109956, 0.00493888, 0.00493888),
            upBounds = cms.vdouble(16.5),
            values = cms.vdouble(1.00159, 0.992869)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(16.5),
            uncertainties = cms.vdouble(0.00112887, 0.00112887, 0.00481407, 0.00481407),
            upBounds = cms.vdouble(18.5),
            values = cms.vdouble(0.993201, 1.02899)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(18.5),
            uncertainties = cms.vdouble(0.0012414, 0.0012414, 0.00502105, 0.00502105),
            upBounds = cms.vdouble(20.5),
            values = cms.vdouble(0.991425, 1.03468)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(20.5),
            uncertainties = cms.vdouble(0.00142369, 0.00142369, 0.00545553, 0.00545553),
            upBounds = cms.vdouble(22.5),
            values = cms.vdouble(0.989716, 1.03941)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(22.5),
            uncertainties = cms.vdouble(0.00147513, 0.00147513, 0.00538112, 0.00538112),
            upBounds = cms.vdouble(25.5),
            values = cms.vdouble(0.98674, 1.04837)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(25.5),
            uncertainties = cms.vdouble(0.00188024, 0.00188024, 0.00643049, 0.00643049),
            upBounds = cms.vdouble(30.5),
            values = cms.vdouble(0.976922, 1.07893)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(30.5),
            uncertainties = cms.vdouble(0.00440431, 0.00440431, 0.0142389, 0.0142389),
            upBounds = cms.vdouble(100.5),
            values = cms.vdouble(0.959731, 1.13018)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(100.5),
            uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
            upBounds = cms.vdouble(999999999),
            values = cms.vdouble(1, 1)
        )
    ),
    variables = cms.vstring('nVert')
)

process.ShowerShapeHighR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.ShowerShapeHighR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.ShowerShapeLowR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.ShowerShapeLowR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.SigmaEOverEShift = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(cms.PSet(
            lowBounds = cms.vdouble(0.0),
            uncertainties = cms.vdouble(0.05),
            upBounds = cms.vdouble(999.0),
            values = cms.vdouble(0.0)
        )),
        variables = cms.vstring('abs(superCluster.eta)')
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('SigmaEOverEShift'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSigEOverEShift')
)

process.SigmaEOverESmearing = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('SigmaEOverESmearing'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSigEoverESmearing')
)

process.SigmaEOverESmearing_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('SigmaEOverESmearing'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(),
    OverallRange = cms.string('1'),
    PhotonMethodName = cms.string('FlashggPhotonSigEoverESmearingEGMTool')
)

process.TriggerWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.0),
                uncertainties = cms.vdouble(0.0042802276, 0.0042802276),
                upBounds = cms.vdouble(0.56, 1.5, 35.0),
                values = cms.vdouble(0.5962935611)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 35.0),
                uncertainties = cms.vdouble(0.0027047543, 0.0027047543),
                upBounds = cms.vdouble(0.56, 1.5, 37.0),
                values = cms.vdouble(0.7301764945)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 37),
                uncertainties = cms.vdouble(0.0022497019, 0.0022497019),
                upBounds = cms.vdouble(0.56, 1.5, 40.0),
                values = cms.vdouble(0.748132908)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 40.0),
                uncertainties = cms.vdouble(0.0026773882, 0.0026773882),
                upBounds = cms.vdouble(0.56, 1.5, 45.0),
                values = cms.vdouble(0.7715837809)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 45.0),
                uncertainties = cms.vdouble(0.0034204121, 0.0034204121),
                upBounds = cms.vdouble(0.56, 1.5, 50.0),
                values = cms.vdouble(0.7885084282)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 50.0),
                uncertainties = cms.vdouble(0.0151426244, 0.0151426244),
                upBounds = cms.vdouble(0.56, 1.5, 60.0),
                values = cms.vdouble(0.8106800401)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 60.0),
                uncertainties = cms.vdouble(0.0186715085, 0.0186715085),
                upBounds = cms.vdouble(0.56, 1.5, 70.0),
                values = cms.vdouble(0.8403040278)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 70.0),
                uncertainties = cms.vdouble(0.0226546537, 0.0226546537),
                upBounds = cms.vdouble(0.56, 1.5, 90.0),
                values = cms.vdouble(0.8403394687)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 90.0),
                uncertainties = cms.vdouble(0.0267241583, 0.0267241583),
                upBounds = cms.vdouble(0.56, 1.5, 99999999),
                values = cms.vdouble(0.9294116662)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 0.0),
                uncertainties = cms.vdouble(0.0018669979, 0.0018669979),
                upBounds = cms.vdouble(0.85, 1.5, 35.0),
                values = cms.vdouble(0.8185203301)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 35.0),
                uncertainties = cms.vdouble(0.0010776168, 0.0010776168),
                upBounds = cms.vdouble(0.85, 1.5, 37.0),
                values = cms.vdouble(0.9430487014)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 37.0),
                uncertainties = cms.vdouble(0.0010044933, 0.0010044933),
                upBounds = cms.vdouble(0.85, 1.5, 40.0),
                values = cms.vdouble(0.950231542)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 40.0),
                uncertainties = cms.vdouble(0.0010923803, 0.0010923803),
                upBounds = cms.vdouble(0.85, 1.5, 45.0),
                values = cms.vdouble(0.9569881714)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 45.0),
                uncertainties = cms.vdouble(0.0010009792, 0.0010009792),
                upBounds = cms.vdouble(0.85, 1.5, 50.0),
                values = cms.vdouble(0.9607761449)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 50.0),
                uncertainties = cms.vdouble(0.0020609352, 0.0020609352),
                upBounds = cms.vdouble(0.85, 1.5, 60.0),
                values = cms.vdouble(0.9667723989)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 60.0),
                uncertainties = cms.vdouble(0.0019261782, 0.0019261782),
                upBounds = cms.vdouble(0.85, 1.5, 70.0),
                values = cms.vdouble(0.9735556426)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 70.0),
                uncertainties = cms.vdouble(0.0014640275, 0.0014640275),
                upBounds = cms.vdouble(0.85, 1.5, 90.0),
                values = cms.vdouble(0.9779985569)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 90.0),
                uncertainties = cms.vdouble(0.0013325485, 0.0013325485),
                upBounds = cms.vdouble(0.85, 1.5, 99999999),
                values = cms.vdouble(0.9846204583)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 0.0),
                uncertainties = cms.vdouble(0.0091110904, 0.0091110904),
                upBounds = cms.vdouble(999, 1.5, 35.0),
                values = cms.vdouble(0.8487571377)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 35.0),
                uncertainties = cms.vdouble(0.002388788, 0.002388788),
                upBounds = cms.vdouble(999, 1.5, 37.0),
                values = cms.vdouble(0.9553428958)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 37.0),
                uncertainties = cms.vdouble(0.0029732333, 0.0029732333),
                upBounds = cms.vdouble(999, 1.5, 40.0),
                values = cms.vdouble(0.9624070784)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 40.0),
                uncertainties = cms.vdouble(0.0010306645, 0.0010306645),
                upBounds = cms.vdouble(999, 1.5, 45.0),
                values = cms.vdouble(0.9693638237)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 45.0),
                uncertainties = cms.vdouble(0.0010351271, 0.0010351271),
                upBounds = cms.vdouble(999, 1.5, 50.0),
                values = cms.vdouble(0.9755313942)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 50.0),
                uncertainties = cms.vdouble(0.0021733865, 0.0021733865),
                upBounds = cms.vdouble(999, 1.5, 60.0),
                values = cms.vdouble(0.9777963391)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 60.0),
                uncertainties = cms.vdouble(0.0046656885, 0.0046656885),
                upBounds = cms.vdouble(999, 1.5, 70.0),
                values = cms.vdouble(0.981216161)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 70.0),
                uncertainties = cms.vdouble(0.0010262855, 0.0010262855),
                upBounds = cms.vdouble(999, 1.5, 90.0),
                values = cms.vdouble(0.984554268)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 90.0),
                uncertainties = cms.vdouble(0.0010973696, 0.0010973696),
                upBounds = cms.vdouble(999, 1.5, 99999999),
                values = cms.vdouble(0.9902588867)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0026339183, 0.0026339183),
                upBounds = cms.vdouble(0.85, 3.0, 35.0),
                values = cms.vdouble(0.6297968504)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 35.0),
                uncertainties = cms.vdouble(0.0026759022, 0.0026759022),
                upBounds = cms.vdouble(0.85, 3.0, 37.0),
                values = cms.vdouble(0.8049372754)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 37.0),
                uncertainties = cms.vdouble(0.0021738261, 0.0021738261),
                upBounds = cms.vdouble(0.85, 3.0, 40.0),
                values = cms.vdouble(0.8314952358)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 40.0),
                uncertainties = cms.vdouble(0.0015238071, 0.0015238071),
                upBounds = cms.vdouble(0.85, 3.0, 45.0),
                values = cms.vdouble(0.8544229767)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 45.0),
                uncertainties = cms.vdouble(0.0028254297, 0.0028254297),
                upBounds = cms.vdouble(0.85, 3.0, 50.0),
                values = cms.vdouble(0.8875746672)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 50.0),
                uncertainties = cms.vdouble(0.0081161238, 0.0081161238),
                upBounds = cms.vdouble(0.85, 3.0, 60.0),
                values = cms.vdouble(0.9033407955)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0071133392, 0.0071133392),
                upBounds = cms.vdouble(0.85, 3.0, 70.0),
                values = cms.vdouble(0.9207605401)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0075500652, 0.0075500652),
                upBounds = cms.vdouble(0.85, 3.0, 90.0),
                values = cms.vdouble(0.9410420565)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 90.0),
                uncertainties = cms.vdouble(0.0063473795, 0.0063473795),
                upBounds = cms.vdouble(0.85, 3.0, 99999999),
                values = cms.vdouble(0.9586907211)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0022876326, 0.0022876326),
                upBounds = cms.vdouble(0.9, 3.0, 35.0),
                values = cms.vdouble(0.7816089799)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 35.0),
                uncertainties = cms.vdouble(0.0013852381, 0.0013852381),
                upBounds = cms.vdouble(0.9, 3.0, 37.0),
                values = cms.vdouble(0.9601546944)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 37.0),
                uncertainties = cms.vdouble(0.0010225346, 0.0010225346),
                upBounds = cms.vdouble(0.9, 3.0, 40.0),
                values = cms.vdouble(0.9728943976)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 40.0),
                uncertainties = cms.vdouble(0.0010733513, 0.0010733513),
                upBounds = cms.vdouble(0.9, 3.0, 45.0),
                values = cms.vdouble(0.9787293111)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 45.0),
                uncertainties = cms.vdouble(0.0011665271, 0.0011665271),
                upBounds = cms.vdouble(0.9, 3.0, 50.0),
                values = cms.vdouble(0.9836865868)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 50.0),
                uncertainties = cms.vdouble(0.0022443143, 0.0022443143),
                upBounds = cms.vdouble(0.9, 3.0, 60.0),
                values = cms.vdouble(0.9845440645)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0026256553, 0.0026256553),
                upBounds = cms.vdouble(0.9, 3.0, 70.0),
                values = cms.vdouble(0.9863780801)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0017879421, 0.0017879421),
                upBounds = cms.vdouble(0.9, 3.0, 90.0),
                values = cms.vdouble(0.9913050524)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 90.0),
                uncertainties = cms.vdouble(0.0021466622, 0.0021466622),
                upBounds = cms.vdouble(0.9, 3.0, 99999999),
                values = cms.vdouble(0.9969391106)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0026613486, 0.0026613486),
                upBounds = cms.vdouble(999, 3.0, 35.0),
                values = cms.vdouble(0.7758811194)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 35.0),
                uncertainties = cms.vdouble(0.0022454963, 0.0022454963),
                upBounds = cms.vdouble(999, 3.0, 37.0),
                values = cms.vdouble(0.9592830235)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 37.0),
                uncertainties = cms.vdouble(0.0010260476, 0.0010260476),
                upBounds = cms.vdouble(999, 3.0, 40.0),
                values = cms.vdouble(0.9692856214)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 40.0),
                uncertainties = cms.vdouble(0.0010342726, 0.0010342726),
                upBounds = cms.vdouble(999, 3.0, 45.0),
                values = cms.vdouble(0.9763703079)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 45.0),
                uncertainties = cms.vdouble(0.0010759694, 0.0010759694),
                upBounds = cms.vdouble(999, 3.0, 50.0),
                values = cms.vdouble(0.9814613177)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001591228, 0.001591228),
                upBounds = cms.vdouble(999, 3.0, 60.0),
                values = cms.vdouble(0.9825431442)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0015265344, 0.0015265344),
                upBounds = cms.vdouble(999, 3.0, 70.0),
                values = cms.vdouble(0.9857720941)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0010792083, 0.0010792083),
                upBounds = cms.vdouble(999, 3.0, 90.0),
                values = cms.vdouble(0.9904181104)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 90.0),
                uncertainties = cms.vdouble(0.0036468351, 0.0036468351),
                upBounds = cms.vdouble(999, 3.0, 99999999),
                values = cms.vdouble(0.9923572396)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 3.0, 0),
                uncertainties = cms.vdouble(1.0, 1.0),
                upBounds = cms.vdouble(999, 999, 999999),
                values = cms.vdouble(1.0)
            )
        ),
        variables = cms.vstring(
            'full5x5_r9', 
            'abs(superCluster.eta)', 
            'pt'
        )
    ),
    BinList2 = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.0),
                uncertainties = cms.vdouble(0.0058060921, 0.0058060921),
                upBounds = cms.vdouble(0.56, 1.5, 28.0),
                values = cms.vdouble(0.6155988939)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 28.0),
                uncertainties = cms.vdouble(0.0035125975, 0.0035125975),
                upBounds = cms.vdouble(0.56, 1.5, 31.0),
                values = cms.vdouble(0.7165819087)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 31.0),
                uncertainties = cms.vdouble(0.0032428598, 0.0032428598),
                upBounds = cms.vdouble(0.56, 1.5, 35.0),
                values = cms.vdouble(0.7381962831)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 35.0),
                uncertainties = cms.vdouble(0.0030303634, 0.0030303634),
                upBounds = cms.vdouble(0.56, 1.5, 40.0),
                values = cms.vdouble(0.7671925006)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 40.0),
                uncertainties = cms.vdouble(0.0021626971, 0.0021626971),
                upBounds = cms.vdouble(0.56, 1.5, 45.0),
                values = cms.vdouble(0.7999358222)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 45.0),
                uncertainties = cms.vdouble(0.0035699597, 0.0035699597),
                upBounds = cms.vdouble(0.56, 1.5, 50.0),
                values = cms.vdouble(0.8254675016)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 50.0),
                uncertainties = cms.vdouble(0.0112021484, 0.0112021484),
                upBounds = cms.vdouble(0.56, 1.5, 60.0),
                values = cms.vdouble(0.829703054)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 60.0),
                uncertainties = cms.vdouble(0.0161493893, 0.0161493893),
                upBounds = cms.vdouble(0.56, 1.5, 70.0),
                values = cms.vdouble(0.8451584417)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 70.0),
                uncertainties = cms.vdouble(0.0194779109, 0.0194779109),
                upBounds = cms.vdouble(0.56, 1.5, 90.0),
                values = cms.vdouble(0.8522482004)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 90.0),
                uncertainties = cms.vdouble(0.0296562368, 0.0296562368),
                upBounds = cms.vdouble(0.56, 1.5, 99999999),
                values = cms.vdouble(0.8871193652)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 0.0),
                uncertainties = cms.vdouble(0.0010278544, 0.0010278544),
                upBounds = cms.vdouble(0.85, 1.5, 28.0),
                values = cms.vdouble(0.902848697)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 28.0),
                uncertainties = cms.vdouble(0.0018686864, 0.0018686864),
                upBounds = cms.vdouble(0.85, 1.5, 31.0),
                values = cms.vdouble(0.9739174387)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 31.0),
                uncertainties = cms.vdouble(0.0010128057, 0.0010128057),
                upBounds = cms.vdouble(0.85, 1.5, 35.0),
                values = cms.vdouble(0.9756211698)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 35.0),
                uncertainties = cms.vdouble(0.0010379176, 0.0010379176),
                upBounds = cms.vdouble(0.85, 1.5, 40.0),
                values = cms.vdouble(0.9785859435)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 40.0),
                uncertainties = cms.vdouble(0.0010275549, 0.0010275549),
                upBounds = cms.vdouble(0.85, 1.5, 45.0),
                values = cms.vdouble(0.9814869681)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 45.0),
                uncertainties = cms.vdouble(0.0011650567, 0.0011650567),
                upBounds = cms.vdouble(0.85, 1.5, 50.0),
                values = cms.vdouble(0.9836603606)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 50.0),
                uncertainties = cms.vdouble(0.0010012441, 0.0010012441),
                upBounds = cms.vdouble(0.85, 1.5, 60.0),
                values = cms.vdouble(0.9808533747)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 60.0),
                uncertainties = cms.vdouble(0.0024188585, 0.0024188585),
                upBounds = cms.vdouble(0.85, 1.5, 70.0),
                values = cms.vdouble(0.9788313651)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 70.0),
                uncertainties = cms.vdouble(0.0012890816, 0.0012890816),
                upBounds = cms.vdouble(0.85, 1.5, 90.0),
                values = cms.vdouble(0.976605377)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.56, 0.0, 90.0),
                uncertainties = cms.vdouble(0.0022197084, 0.0022197084),
                upBounds = cms.vdouble(0.85, 1.5, 99999999),
                values = cms.vdouble(0.9667617117)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 0.0),
                uncertainties = cms.vdouble(0.0065966201, 0.0065966201),
                upBounds = cms.vdouble(999, 1.5, 28.0),
                values = cms.vdouble(0.8933536854)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 28.0),
                uncertainties = cms.vdouble(0.0017666493, 0.0017666493),
                upBounds = cms.vdouble(999, 1.5, 31.0),
                values = cms.vdouble(0.9973958724)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 31.0),
                uncertainties = cms.vdouble(0.001086051, 0.001086051),
                upBounds = cms.vdouble(999, 1.5, 35.0),
                values = cms.vdouble(0.9980479262)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 35.0),
                uncertainties = cms.vdouble(0.0010000106, 0.0010000106),
                upBounds = cms.vdouble(999, 1.5, 40.0),
                values = cms.vdouble(0.998728949)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001000066, 0.001000066),
                upBounds = cms.vdouble(999, 1.5, 45.0),
                values = cms.vdouble(0.9992636424)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 45.0),
                uncertainties = cms.vdouble(0.0010000824, 0.0010000824),
                upBounds = cms.vdouble(999, 1.5, 50.0),
                values = cms.vdouble(0.999468697)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 50.0),
                uncertainties = cms.vdouble(0.0010000075, 0.0010000075),
                upBounds = cms.vdouble(999, 1.5, 60.0),
                values = cms.vdouble(0.9995552559)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 60.0),
                uncertainties = cms.vdouble(0.0010531353, 0.0010531353),
                upBounds = cms.vdouble(999, 1.5, 70.0),
                values = cms.vdouble(0.9992541003)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 70.0),
                uncertainties = cms.vdouble(0.0010000525, 0.0010000525),
                upBounds = cms.vdouble(999, 1.5, 90.0),
                values = cms.vdouble(0.9996086647)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 90.0),
                uncertainties = cms.vdouble(0.0010000001, 0.0010000001),
                upBounds = cms.vdouble(999, 1.5, 99999999),
                values = cms.vdouble(0.9996779894)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0044630622, 0.0044630622),
                upBounds = cms.vdouble(0.85, 3.0, 28.0),
                values = cms.vdouble(0.6100544113)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 28.0),
                uncertainties = cms.vdouble(0.0041193336, 0.0041193336),
                upBounds = cms.vdouble(0.85, 3.0, 31.0),
                values = cms.vdouble(0.7427840769)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 31.0),
                uncertainties = cms.vdouble(0.0023197541, 0.0023197541),
                upBounds = cms.vdouble(0.85, 3.0, 35.0),
                values = cms.vdouble(0.7761341323)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 35.0),
                uncertainties = cms.vdouble(0.0018272149, 0.0018272149),
                upBounds = cms.vdouble(0.85, 3.0, 40.0),
                values = cms.vdouble(0.8117452882)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 40.0),
                uncertainties = cms.vdouble(0.0017371369, 0.0017371369),
                upBounds = cms.vdouble(0.85, 3.0, 45.0),
                values = cms.vdouble(0.831908844)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 45.0),
                uncertainties = cms.vdouble(0.0029028382, 0.0029028382),
                upBounds = cms.vdouble(0.85, 3.0, 50.0),
                values = cms.vdouble(0.8583582498)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 50.0),
                uncertainties = cms.vdouble(0.0067434212, 0.0067434212),
                upBounds = cms.vdouble(0.85, 3.0, 60.0),
                values = cms.vdouble(0.8736432627)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0088928808, 0.0088928808),
                upBounds = cms.vdouble(0.85, 3.0, 70.0),
                values = cms.vdouble(0.8907409748)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0083321492, 0.0083321492),
                upBounds = cms.vdouble(0.85, 3.0, 90.0),
                values = cms.vdouble(0.9046665266)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 90.0),
                uncertainties = cms.vdouble(0.0092567264, 0.0092567264),
                upBounds = cms.vdouble(0.85, 3.0, 99999999),
                values = cms.vdouble(0.9190711276)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0043867136, 0.0043867136),
                upBounds = cms.vdouble(0.9, 3.0, 28.0),
                values = cms.vdouble(0.8283101205)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 28.0),
                uncertainties = cms.vdouble(0.0024484718, 0.0024484718),
                upBounds = cms.vdouble(0.9, 3.0, 31.0),
                values = cms.vdouble(0.9538552575)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 31.0),
                uncertainties = cms.vdouble(0.0012894149, 0.0012894149),
                upBounds = cms.vdouble(0.9, 3.0, 35.0),
                values = cms.vdouble(0.9597166341)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 35.0),
                uncertainties = cms.vdouble(0.0016910488, 0.0016910488),
                upBounds = cms.vdouble(0.9, 3.0, 40.0),
                values = cms.vdouble(0.9617373097)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 40.0),
                uncertainties = cms.vdouble(0.0010003997, 0.0010003997),
                upBounds = cms.vdouble(0.9, 3.0, 45.0),
                values = cms.vdouble(0.9624428298)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 45.0),
                uncertainties = cms.vdouble(0.0015842487, 0.0015842487),
                upBounds = cms.vdouble(0.9, 3.0, 50.0),
                values = cms.vdouble(0.9581303007)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 50.0),
                uncertainties = cms.vdouble(0.0030254988, 0.0030254988),
                upBounds = cms.vdouble(0.9, 3.0, 60.0),
                values = cms.vdouble(0.9621293579)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0039064632, 0.0039064632),
                upBounds = cms.vdouble(0.9, 3.0, 70.0),
                values = cms.vdouble(0.967026223)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0031524223, 0.0031524223),
                upBounds = cms.vdouble(0.9, 3.0, 90.0),
                values = cms.vdouble(0.9721855102)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 1.5, 90.0),
                uncertainties = cms.vdouble(0.0031751105, 0.0031751105),
                upBounds = cms.vdouble(0.9, 3.0, 99999999),
                values = cms.vdouble(0.9753380476)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0010432162, 0.0010432162),
                upBounds = cms.vdouble(999, 3.0, 28.0),
                values = cms.vdouble(0.8582078363)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 28.0),
                uncertainties = cms.vdouble(0.0018317715, 0.0018317715),
                upBounds = cms.vdouble(999, 3.0, 31.0),
                values = cms.vdouble(0.9911788518)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 31.0),
                uncertainties = cms.vdouble(0.0011267834, 0.0011267834),
                upBounds = cms.vdouble(999, 3.0, 35.0),
                values = cms.vdouble(0.9961663139)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 35.0),
                uncertainties = cms.vdouble(0.001000539, 0.001000539),
                upBounds = cms.vdouble(999, 3.0, 40.0),
                values = cms.vdouble(0.9974520554)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 40.0),
                uncertainties = cms.vdouble(0.0011367326, 0.0011367326),
                upBounds = cms.vdouble(999, 3.0, 45.0),
                values = cms.vdouble(0.998387259)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 45.0),
                uncertainties = cms.vdouble(0.0010000889, 0.0010000889),
                upBounds = cms.vdouble(999, 3.0, 50.0),
                values = cms.vdouble(0.9988958563)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 50.0),
                uncertainties = cms.vdouble(0.0010002577, 0.0010002577),
                upBounds = cms.vdouble(999, 3.0, 60.0),
                values = cms.vdouble(0.9987919975)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 60.0),
                uncertainties = cms.vdouble(0.001040689, 0.001040689),
                upBounds = cms.vdouble(999, 3.0, 70.0),
                values = cms.vdouble(0.999279006)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0010003602, 0.0010003602),
                upBounds = cms.vdouble(999, 3.0, 90.0),
                values = cms.vdouble(0.999472035)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 90.0),
                uncertainties = cms.vdouble(0.0010000015, 0.0010000015),
                upBounds = cms.vdouble(999, 3.0, 99999999),
                values = cms.vdouble(0.9995989436)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 3.0, 0),
                uncertainties = cms.vdouble(1.0, 1.0),
                upBounds = cms.vdouble(999, 999, 999999),
                values = cms.vdouble(1.0)
            )
        ),
        variables = cms.vstring(
            'full5x5_r9', 
            'abs(superCluster.eta)', 
            'pt'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('TriggerWeight'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('pt<99999 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.binInfo2016 = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(-6.0, 0.0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(-2.5, 9999999.0),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(-2, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 10),
            uncertainties = cms.vdouble(0.021),
            upBounds = cms.vdouble(-2, 20),
            values = cms.vdouble(1.014)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 20),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(-2, 35),
            values = cms.vdouble(0.991)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 35),
            uncertainties = cms.vdouble(0.006),
            upBounds = cms.vdouble(-2, 50),
            values = cms.vdouble(0.999)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 50),
            uncertainties = cms.vdouble(0.008),
            upBounds = cms.vdouble(-2, 100),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 100),
            uncertainties = cms.vdouble(0.032),
            upBounds = cms.vdouble(-2, 200),
            values = cms.vdouble(1.014)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 200),
            uncertainties = cms.vdouble(0.089),
            upBounds = cms.vdouble(-2, 500),
            values = cms.vdouble(0.966)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 500),
            uncertainties = cms.vdouble(0.089),
            upBounds = cms.vdouble(-2, 999999999),
            values = cms.vdouble(0.966)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(-1.566, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 10),
            uncertainties = cms.vdouble(0.017),
            upBounds = cms.vdouble(-1.566, 20),
            values = cms.vdouble(0.962)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 20),
            uncertainties = cms.vdouble(0.012),
            upBounds = cms.vdouble(-1.566, 35),
            values = cms.vdouble(0.951)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 35),
            uncertainties = cms.vdouble(0.01),
            upBounds = cms.vdouble(-1.566, 50),
            values = cms.vdouble(0.968)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 50),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(-1.566, 100),
            values = cms.vdouble(0.977)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 100),
            uncertainties = cms.vdouble(0.01),
            upBounds = cms.vdouble(-1.566, 200),
            values = cms.vdouble(0.983)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 200),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(-1.566, 500),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 500),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(-1.566, 99999999),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 0),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 10),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 10),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 20),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 20),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 35),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 35),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 50),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 50),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 100),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 100),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 200),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 200),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 500),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 500),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 9999999),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 0),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 10),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 10),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 20),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 20),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 35),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 35),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 50),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 50),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 100),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 100),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 200),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 200),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 500),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 500),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 9999999),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(0, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 10),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0, 20),
            values = cms.vdouble(0.953)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 20),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0, 35),
            values = cms.vdouble(0.952)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 35),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(0, 50),
            values = cms.vdouble(0.957)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 50),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(0, 100),
            values = cms.vdouble(0.963)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 100),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(0, 200),
            values = cms.vdouble(0.982)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 200),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0, 500),
            values = cms.vdouble(0.979)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 500),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0, 99999999),
            values = cms.vdouble(0.979)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(0.8, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 10),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0.8, 20),
            values = cms.vdouble(0.954)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 20),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0.8, 35),
            values = cms.vdouble(0.966)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 35),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(0.8, 50),
            values = cms.vdouble(0.976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 50),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(0.8, 100),
            values = cms.vdouble(0.979)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 100),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(0.8, 200),
            values = cms.vdouble(0.991)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 200),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0.8, 500),
            values = cms.vdouble(0.976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 500),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0.8, 99999999),
            values = cms.vdouble(0.976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(1.444, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 10),
            uncertainties = cms.vdouble(0.11),
            upBounds = cms.vdouble(1.444, 20),
            values = cms.vdouble(0.974)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 20),
            uncertainties = cms.vdouble(0.018),
            upBounds = cms.vdouble(1.444, 35),
            values = cms.vdouble(0.947)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 35),
            uncertainties = cms.vdouble(0.004),
            upBounds = cms.vdouble(1.444, 50),
            values = cms.vdouble(0.965)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 50),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(1.444, 100),
            values = cms.vdouble(0.97)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 100),
            uncertainties = cms.vdouble(0.011),
            upBounds = cms.vdouble(1.444, 200),
            values = cms.vdouble(0.99)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 200),
            uncertainties = cms.vdouble(0.025),
            upBounds = cms.vdouble(1.444, 500),
            values = cms.vdouble(0.984)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 500),
            uncertainties = cms.vdouble(0.025),
            upBounds = cms.vdouble(1.444, 9999999),
            values = cms.vdouble(0.984)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 0),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 10),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 10),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 20),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 20),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 35),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 35),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 50),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 50),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 100),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 100),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 200),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 200),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 500),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 500),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 9999999),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(2, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 10),
            uncertainties = cms.vdouble(0.017),
            upBounds = cms.vdouble(2, 20),
            values = cms.vdouble(0.971)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 20),
            uncertainties = cms.vdouble(0.012),
            upBounds = cms.vdouble(2, 35),
            values = cms.vdouble(0.933)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 35),
            uncertainties = cms.vdouble(0.01),
            upBounds = cms.vdouble(2, 50),
            values = cms.vdouble(0.957)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 50),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(2, 100),
            values = cms.vdouble(0.968)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 100),
            uncertainties = cms.vdouble(0.011),
            upBounds = cms.vdouble(2, 200),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 200),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(2, 500),
            values = cms.vdouble(0.952)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 500),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(2, 99999999),
            values = cms.vdouble(0.952)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(2.5, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 10),
            uncertainties = cms.vdouble(0.021),
            upBounds = cms.vdouble(2.5, 20),
            values = cms.vdouble(0.961)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 20),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(2.5, 35),
            values = cms.vdouble(0.953)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 35),
            uncertainties = cms.vdouble(0.006),
            upBounds = cms.vdouble(2.5, 50),
            values = cms.vdouble(0.961)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 50),
            uncertainties = cms.vdouble(0.008),
            upBounds = cms.vdouble(2.5, 100),
            values = cms.vdouble(0.969)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 100),
            uncertainties = cms.vdouble(0.032),
            upBounds = cms.vdouble(2.5, 200),
            values = cms.vdouble(0.994)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 200),
            uncertainties = cms.vdouble(0.09),
            upBounds = cms.vdouble(2.5, 500),
            values = cms.vdouble(1.018)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 500),
            uncertainties = cms.vdouble(0.09),
            upBounds = cms.vdouble(2.5, 999999999),
            values = cms.vdouble(1.018)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2.5, 0.0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(6.0, 999999999.0),
            values = cms.vdouble(1.0)
        )
    ),
    variables = cms.vstring(
        'eta', 
        'pt'
    )
)

process.electronVetoBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0024),
            upBounds = cms.vdouble(1.5, 0.85),
            values = cms.vdouble(0.9838)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85),
            uncertainties = cms.vdouble(0.0009),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.9913)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.018),
            upBounds = cms.vdouble(6.0, 0.9),
            values = cms.vdouble(0.9777)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.0026),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.9784)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.electronVetoSF = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.0024),
                upBounds = cms.vdouble(1.5, 0.85),
                values = cms.vdouble(0.9838)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85),
                uncertainties = cms.vdouble(0.0009),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.9913)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.018),
                upBounds = cms.vdouble(6.0, 0.9),
                values = cms.vdouble(0.9777)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9),
                uncertainties = cms.vdouble(0.0026),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.9784)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('electronVetoSF'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.emptyBins = cms.PSet(
    bins = cms.VPSet(),
    variables = cms.vstring('1')
)

process.emptySigma = cms.PSet(
    firstVar = cms.vint32(),
    secondVar = cms.vint32()
)

process.globalVariables = cms.PSet(
    dataPu = cms.vdouble(),
    dumpLHEInfo = cms.bool(False),
    extraFloats = cms.PSet(

    ),
    lhePartTable = cms.InputTag("lheInfoTable","LHEPart"),
    lheTable = cms.InputTag("lheInfoTable","LHE"),
    mcPu = cms.vdouble(),
    puBins = cms.vdouble(),
    puInfo = cms.InputTag("slimmedAddPileupInfo"),
    puReWeight = cms.bool(False),
    rho = cms.InputTag("fixedGridRhoAll"),
    vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
)

process.leadPixelSeedBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.00401807),
            upBounds = cms.vdouble(1.5, 0.85, 0.1),
            values = cms.vdouble(0.978)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, -0.1),
            uncertainties = cms.vdouble(-0.00200421),
            upBounds = cms.vdouble(1.5, 999.0, 0.1),
            values = cms.vdouble(0.9824)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.0224756),
            upBounds = cms.vdouble(6.0, 0.9, 0.1),
            values = cms.vdouble(0.9168)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, -0.1),
            uncertainties = cms.vdouble(-0.00631264),
            upBounds = cms.vdouble(6.0, 999.0, 0.1),
            values = cms.vdouble(0.9403)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0162106),
            upBounds = cms.vdouble(1.5, 0.85, 1.1),
            values = cms.vdouble(1.08876)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, 0.9),
            uncertainties = cms.vdouble(0.0678807),
            upBounds = cms.vdouble(1.5, 999.0, 1.1),
            values = cms.vdouble(1.5961)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0263745),
            upBounds = cms.vdouble(6.0, 0.9, 1.1),
            values = cms.vdouble(1.09763)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, 0.9),
            uncertainties = cms.vdouble(0.0214274),
            upBounds = cms.vdouble(6.0, 999.0, 1.1),
            values = cms.vdouble(1.20264)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9', 
        'hasPixelSeed'
    )
)

process.leadTriggerScaleBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.0),
            uncertainties = cms.vdouble(0.0042802276, 0.0042802276),
            upBounds = cms.vdouble(0.56, 1.5, 35.0),
            values = cms.vdouble(0.5962935611)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 35.0),
            uncertainties = cms.vdouble(0.0027047543, 0.0027047543),
            upBounds = cms.vdouble(0.56, 1.5, 37.0),
            values = cms.vdouble(0.7301764945)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 37),
            uncertainties = cms.vdouble(0.0022497019, 0.0022497019),
            upBounds = cms.vdouble(0.56, 1.5, 40.0),
            values = cms.vdouble(0.748132908)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 40.0),
            uncertainties = cms.vdouble(0.0026773882, 0.0026773882),
            upBounds = cms.vdouble(0.56, 1.5, 45.0),
            values = cms.vdouble(0.7715837809)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 45.0),
            uncertainties = cms.vdouble(0.0034204121, 0.0034204121),
            upBounds = cms.vdouble(0.56, 1.5, 50.0),
            values = cms.vdouble(0.7885084282)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 50.0),
            uncertainties = cms.vdouble(0.0151426244, 0.0151426244),
            upBounds = cms.vdouble(0.56, 1.5, 60.0),
            values = cms.vdouble(0.8106800401)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 60.0),
            uncertainties = cms.vdouble(0.0186715085, 0.0186715085),
            upBounds = cms.vdouble(0.56, 1.5, 70.0),
            values = cms.vdouble(0.8403040278)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 70.0),
            uncertainties = cms.vdouble(0.0226546537, 0.0226546537),
            upBounds = cms.vdouble(0.56, 1.5, 90.0),
            values = cms.vdouble(0.8403394687)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 90.0),
            uncertainties = cms.vdouble(0.0267241583, 0.0267241583),
            upBounds = cms.vdouble(0.56, 1.5, 99999999),
            values = cms.vdouble(0.9294116662)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 0.0),
            uncertainties = cms.vdouble(0.0018669979, 0.0018669979),
            upBounds = cms.vdouble(0.85, 1.5, 35.0),
            values = cms.vdouble(0.8185203301)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 35.0),
            uncertainties = cms.vdouble(0.0010776168, 0.0010776168),
            upBounds = cms.vdouble(0.85, 1.5, 37.0),
            values = cms.vdouble(0.9430487014)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 37.0),
            uncertainties = cms.vdouble(0.0010044933, 0.0010044933),
            upBounds = cms.vdouble(0.85, 1.5, 40.0),
            values = cms.vdouble(0.950231542)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 40.0),
            uncertainties = cms.vdouble(0.0010923803, 0.0010923803),
            upBounds = cms.vdouble(0.85, 1.5, 45.0),
            values = cms.vdouble(0.9569881714)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 45.0),
            uncertainties = cms.vdouble(0.0010009792, 0.0010009792),
            upBounds = cms.vdouble(0.85, 1.5, 50.0),
            values = cms.vdouble(0.9607761449)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 50.0),
            uncertainties = cms.vdouble(0.0020609352, 0.0020609352),
            upBounds = cms.vdouble(0.85, 1.5, 60.0),
            values = cms.vdouble(0.9667723989)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 60.0),
            uncertainties = cms.vdouble(0.0019261782, 0.0019261782),
            upBounds = cms.vdouble(0.85, 1.5, 70.0),
            values = cms.vdouble(0.9735556426)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 70.0),
            uncertainties = cms.vdouble(0.0014640275, 0.0014640275),
            upBounds = cms.vdouble(0.85, 1.5, 90.0),
            values = cms.vdouble(0.9779985569)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 90.0),
            uncertainties = cms.vdouble(0.0013325485, 0.0013325485),
            upBounds = cms.vdouble(0.85, 1.5, 99999999),
            values = cms.vdouble(0.9846204583)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 0.0),
            uncertainties = cms.vdouble(0.0091110904, 0.0091110904),
            upBounds = cms.vdouble(999, 1.5, 35.0),
            values = cms.vdouble(0.8487571377)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 35.0),
            uncertainties = cms.vdouble(0.002388788, 0.002388788),
            upBounds = cms.vdouble(999, 1.5, 37.0),
            values = cms.vdouble(0.9553428958)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 37.0),
            uncertainties = cms.vdouble(0.0029732333, 0.0029732333),
            upBounds = cms.vdouble(999, 1.5, 40.0),
            values = cms.vdouble(0.9624070784)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 40.0),
            uncertainties = cms.vdouble(0.0010306645, 0.0010306645),
            upBounds = cms.vdouble(999, 1.5, 45.0),
            values = cms.vdouble(0.9693638237)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 45.0),
            uncertainties = cms.vdouble(0.0010351271, 0.0010351271),
            upBounds = cms.vdouble(999, 1.5, 50.0),
            values = cms.vdouble(0.9755313942)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 50.0),
            uncertainties = cms.vdouble(0.0021733865, 0.0021733865),
            upBounds = cms.vdouble(999, 1.5, 60.0),
            values = cms.vdouble(0.9777963391)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 60.0),
            uncertainties = cms.vdouble(0.0046656885, 0.0046656885),
            upBounds = cms.vdouble(999, 1.5, 70.0),
            values = cms.vdouble(0.981216161)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 70.0),
            uncertainties = cms.vdouble(0.0010262855, 0.0010262855),
            upBounds = cms.vdouble(999, 1.5, 90.0),
            values = cms.vdouble(0.984554268)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 90.0),
            uncertainties = cms.vdouble(0.0010973696, 0.0010973696),
            upBounds = cms.vdouble(999, 1.5, 99999999),
            values = cms.vdouble(0.9902588867)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0026339183, 0.0026339183),
            upBounds = cms.vdouble(0.85, 3.0, 35.0),
            values = cms.vdouble(0.6297968504)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 35.0),
            uncertainties = cms.vdouble(0.0026759022, 0.0026759022),
            upBounds = cms.vdouble(0.85, 3.0, 37.0),
            values = cms.vdouble(0.8049372754)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 37.0),
            uncertainties = cms.vdouble(0.0021738261, 0.0021738261),
            upBounds = cms.vdouble(0.85, 3.0, 40.0),
            values = cms.vdouble(0.8314952358)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 40.0),
            uncertainties = cms.vdouble(0.0015238071, 0.0015238071),
            upBounds = cms.vdouble(0.85, 3.0, 45.0),
            values = cms.vdouble(0.8544229767)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 45.0),
            uncertainties = cms.vdouble(0.0028254297, 0.0028254297),
            upBounds = cms.vdouble(0.85, 3.0, 50.0),
            values = cms.vdouble(0.8875746672)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 50.0),
            uncertainties = cms.vdouble(0.0081161238, 0.0081161238),
            upBounds = cms.vdouble(0.85, 3.0, 60.0),
            values = cms.vdouble(0.9033407955)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0071133392, 0.0071133392),
            upBounds = cms.vdouble(0.85, 3.0, 70.0),
            values = cms.vdouble(0.9207605401)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0075500652, 0.0075500652),
            upBounds = cms.vdouble(0.85, 3.0, 90.0),
            values = cms.vdouble(0.9410420565)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 90.0),
            uncertainties = cms.vdouble(0.0063473795, 0.0063473795),
            upBounds = cms.vdouble(0.85, 3.0, 99999999),
            values = cms.vdouble(0.9586907211)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0022876326, 0.0022876326),
            upBounds = cms.vdouble(0.9, 3.0, 35.0),
            values = cms.vdouble(0.7816089799)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 35.0),
            uncertainties = cms.vdouble(0.0013852381, 0.0013852381),
            upBounds = cms.vdouble(0.9, 3.0, 37.0),
            values = cms.vdouble(0.9601546944)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 37.0),
            uncertainties = cms.vdouble(0.0010225346, 0.0010225346),
            upBounds = cms.vdouble(0.9, 3.0, 40.0),
            values = cms.vdouble(0.9728943976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 40.0),
            uncertainties = cms.vdouble(0.0010733513, 0.0010733513),
            upBounds = cms.vdouble(0.9, 3.0, 45.0),
            values = cms.vdouble(0.9787293111)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 45.0),
            uncertainties = cms.vdouble(0.0011665271, 0.0011665271),
            upBounds = cms.vdouble(0.9, 3.0, 50.0),
            values = cms.vdouble(0.9836865868)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 50.0),
            uncertainties = cms.vdouble(0.0022443143, 0.0022443143),
            upBounds = cms.vdouble(0.9, 3.0, 60.0),
            values = cms.vdouble(0.9845440645)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0026256553, 0.0026256553),
            upBounds = cms.vdouble(0.9, 3.0, 70.0),
            values = cms.vdouble(0.9863780801)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0017879421, 0.0017879421),
            upBounds = cms.vdouble(0.9, 3.0, 90.0),
            values = cms.vdouble(0.9913050524)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 90.0),
            uncertainties = cms.vdouble(0.0021466622, 0.0021466622),
            upBounds = cms.vdouble(0.9, 3.0, 99999999),
            values = cms.vdouble(0.9969391106)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0026613486, 0.0026613486),
            upBounds = cms.vdouble(999, 3.0, 35.0),
            values = cms.vdouble(0.7758811194)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 35.0),
            uncertainties = cms.vdouble(0.0022454963, 0.0022454963),
            upBounds = cms.vdouble(999, 3.0, 37.0),
            values = cms.vdouble(0.9592830235)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 37.0),
            uncertainties = cms.vdouble(0.0010260476, 0.0010260476),
            upBounds = cms.vdouble(999, 3.0, 40.0),
            values = cms.vdouble(0.9692856214)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 40.0),
            uncertainties = cms.vdouble(0.0010342726, 0.0010342726),
            upBounds = cms.vdouble(999, 3.0, 45.0),
            values = cms.vdouble(0.9763703079)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 45.0),
            uncertainties = cms.vdouble(0.0010759694, 0.0010759694),
            upBounds = cms.vdouble(999, 3.0, 50.0),
            values = cms.vdouble(0.9814613177)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001591228, 0.001591228),
            upBounds = cms.vdouble(999, 3.0, 60.0),
            values = cms.vdouble(0.9825431442)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0015265344, 0.0015265344),
            upBounds = cms.vdouble(999, 3.0, 70.0),
            values = cms.vdouble(0.9857720941)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0010792083, 0.0010792083),
            upBounds = cms.vdouble(999, 3.0, 90.0),
            values = cms.vdouble(0.9904181104)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 90.0),
            uncertainties = cms.vdouble(0.0036468351, 0.0036468351),
            upBounds = cms.vdouble(999, 3.0, 99999999),
            values = cms.vdouble(0.9923572396)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 3.0, 0),
            uncertainties = cms.vdouble(1.0, 1.0),
            upBounds = cms.vdouble(999, 999, 999999),
            values = cms.vdouble(1.0)
        )
    ),
    variables = cms.vstring(
        'full5x5_r9', 
        'abs(superCluster.eta)', 
        'pt'
    )
)

process.looseMvaBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0014),
            upBounds = cms.vdouble(1.5, 0.85),
            values = cms.vdouble(1.0021)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85),
            uncertainties = cms.vdouble(0.0038),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(1.0001)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0014),
            upBounds = cms.vdouble(6.0, 0.9),
            values = cms.vdouble(1.0061)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.0023),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(1.0016)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.materialBinsICHEP = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0007),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.00036),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.00089),
            upBounds = cms.vdouble(6.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.0017),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.materialBinsMoriond17 = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.000455),
            upBounds = cms.vdouble(1.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.000233),
            upBounds = cms.vdouble(1.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.0),
            uncertainties = cms.vdouble(0.002089),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.94),
            uncertainties = cms.vdouble(0.002089),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.00109),
            upBounds = cms.vdouble(999.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.002377),
            upBounds = cms.vdouble(999.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.materialBinsRun1 = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.00035),
            upBounds = cms.vdouble(0.8, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.00033),
            upBounds = cms.vdouble(0.8, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 0.0),
            uncertainties = cms.vdouble(0.00058),
            upBounds = cms.vdouble(1.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 0.94),
            uncertainties = cms.vdouble(0.0012),
            upBounds = cms.vdouble(1.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.0),
            uncertainties = cms.vdouble(0.0022),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.94),
            uncertainties = cms.vdouble(0.0034),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0022),
            upBounds = cms.vdouble(999.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.0034),
            upBounds = cms.vdouble(999.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(10000)
)

process.metJecSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metJecUncertainty'),
    MethodName = cms.string('FlashggMetJecSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.metJerSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metJerUncertainty'),
    MethodName = cms.string('FlashggMetJerSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.metPhoSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metPhoUncertainty'),
    MethodName = cms.string('FlashggMetPhoSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.metUncSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metUncUncertainty'),
    MethodName = cms.string('FlashggMetUncSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.mvaShiftBins = cms.PSet(
    bins = cms.VPSet(cms.PSet(
        lowBounds = cms.vdouble(0.0),
        uncertainties = cms.vdouble(0.0),
        upBounds = cms.vdouble(999.0),
        values = cms.vdouble(0.0)
    )),
    variables = cms.vstring('abs(superCluster.eta)')
)

process.options = cms.untracked.PSet(
    allowUnscheduled = cms.untracked.bool(True),
    wantSummary = cms.untracked.bool(True)
)

process.photonScaleUncertBins = cms.PSet(

)

process.photonSmearBins = cms.PSet(

)

process.preselBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0307),
            upBounds = cms.vdouble(1.5, 0.85),
            values = cms.vdouble(0.9961)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85),
            uncertainties = cms.vdouble(0.0057),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.9981)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0129),
            upBounds = cms.vdouble(6.0, 0.9),
            values = cms.vdouble(1.0054)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.0018),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(1.0061)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.regressionModifier = cms.PSet(
    eOverP_ECALTRKThr = cms.double(0.025),
    electron_config = cms.PSet(
        regressionKey = cms.vstring(
            'electron_eb_ECALonly_lowpt', 
            'electron_eb_ECALonly', 
            'electron_ee_ECALonly_lowpt', 
            'electron_ee_ECALonly', 
            'electron_eb_ECALTRK_lowpt', 
            'electron_eb_ECALTRK', 
            'electron_ee_ECALTRK_lowpt', 
            'electron_ee_ECALTRK'
        ),
        uncertaintyKey = cms.vstring(
            'electron_eb_ECALonly_lowpt_var', 
            'electron_eb_ECALonly_var', 
            'electron_ee_ECALonly_lowpt_var', 
            'electron_ee_ECALonly_var', 
            'electron_eb_ECALTRK_lowpt_var', 
            'electron_eb_ECALTRK_var', 
            'electron_ee_ECALTRK_lowpt_var', 
            'electron_ee_ECALTRK_var'
        )
    ),
    epDiffSig_ECALTRKThr = cms.double(15.0),
    epSig_ECALTRKThr = cms.double(10.0),
    forceHighEnergyEcalTrainingIfSaturated = cms.bool(True),
    highEnergy_ECALTRKThr = cms.double(200.0),
    lowEnergy_ECALTRKThr = cms.double(50.0),
    lowEnergy_ECALonlyThr = cms.double(99999.0),
    modifierName = cms.string('EGRegressionModifierV2'),
    photon_config = cms.PSet(
        regressionKey = cms.vstring(
            'photon_eb_ECALonly_lowpt', 
            'photon_eb_ECALonly', 
            'photon_ee_ECALonly_lowpt', 
            'photon_ee_ECALonly'
        ),
        uncertaintyKey = cms.vstring(
            'photon_eb_ECALonly_lowpt_var', 
            'photon_eb_ECALonly_var', 
            'photon_ee_ECALonly_lowpt_var', 
            'photon_ee_ECALonly_var'
        )
    ),
    rhoCollection = cms.InputTag("fixedGridRhoFastjetAllTmp")
)

process.showerShapeBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(-0.0001),
            upBounds = cms.vdouble(1.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.0),
            uncertainties = cms.vdouble(0.0002),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(-0.0006),
            upBounds = cms.vdouble(1.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.94),
            uncertainties = cms.vdouble(-0.0011),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0015),
            upBounds = cms.vdouble(2.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2.0, 0.0),
            uncertainties = cms.vdouble(0.0004),
            upBounds = cms.vdouble(6.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.0002),
            upBounds = cms.vdouble(2.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2.0, 0.94),
            uncertainties = cms.vdouble(0.0003),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.sigmaEOverEShiftBins = cms.PSet(
    bins = cms.VPSet(cms.PSet(
        lowBounds = cms.vdouble(0.0),
        uncertainties = cms.vdouble(0.05),
        upBounds = cms.vdouble(999.0),
        values = cms.vdouble(0.0)
    )),
    variables = cms.vstring('abs(superCluster.eta)')
)

process.subleadPixelSeedBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.00415083),
            upBounds = cms.vdouble(1.5, 0.85, 0.1),
            values = cms.vdouble(0.978)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, -0.1),
            uncertainties = cms.vdouble(-0.00280026),
            upBounds = cms.vdouble(1.5, 999.0, 0.1),
            values = cms.vdouble(0.9824)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.0225538),
            upBounds = cms.vdouble(6.0, 0.9, 0.1),
            values = cms.vdouble(0.9168)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, -0.1),
            uncertainties = cms.vdouble(-0.00655045),
            upBounds = cms.vdouble(6.0, 999.0, 0.1),
            values = cms.vdouble(0.9403)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0248967),
            upBounds = cms.vdouble(1.5, 0.85, 1.1),
            values = cms.vdouble(1.13196)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, 0.9),
            uncertainties = cms.vdouble(0.0978689),
            upBounds = cms.vdouble(1.5, 999.0, 1.1),
            values = cms.vdouble(1.61512)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0287957),
            upBounds = cms.vdouble(6.0, 0.9, 1.1),
            values = cms.vdouble(1.10623)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, 0.9),
            uncertainties = cms.vdouble(0.0222861),
            upBounds = cms.vdouble(6.0, 999.0, 1.1),
            values = cms.vdouble(1.20311)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9', 
        'hasPixelSeed'
    )
)

process.subleadTriggerScaleBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.0),
            uncertainties = cms.vdouble(0.0058060921, 0.0058060921),
            upBounds = cms.vdouble(0.56, 1.5, 28.0),
            values = cms.vdouble(0.6155988939)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 28.0),
            uncertainties = cms.vdouble(0.0035125975, 0.0035125975),
            upBounds = cms.vdouble(0.56, 1.5, 31.0),
            values = cms.vdouble(0.7165819087)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 31.0),
            uncertainties = cms.vdouble(0.0032428598, 0.0032428598),
            upBounds = cms.vdouble(0.56, 1.5, 35.0),
            values = cms.vdouble(0.7381962831)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 35.0),
            uncertainties = cms.vdouble(0.0030303634, 0.0030303634),
            upBounds = cms.vdouble(0.56, 1.5, 40.0),
            values = cms.vdouble(0.7671925006)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 40.0),
            uncertainties = cms.vdouble(0.0021626971, 0.0021626971),
            upBounds = cms.vdouble(0.56, 1.5, 45.0),
            values = cms.vdouble(0.7999358222)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 45.0),
            uncertainties = cms.vdouble(0.0035699597, 0.0035699597),
            upBounds = cms.vdouble(0.56, 1.5, 50.0),
            values = cms.vdouble(0.8254675016)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 50.0),
            uncertainties = cms.vdouble(0.0112021484, 0.0112021484),
            upBounds = cms.vdouble(0.56, 1.5, 60.0),
            values = cms.vdouble(0.829703054)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 60.0),
            uncertainties = cms.vdouble(0.0161493893, 0.0161493893),
            upBounds = cms.vdouble(0.56, 1.5, 70.0),
            values = cms.vdouble(0.8451584417)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 70.0),
            uncertainties = cms.vdouble(0.0194779109, 0.0194779109),
            upBounds = cms.vdouble(0.56, 1.5, 90.0),
            values = cms.vdouble(0.8522482004)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 90.0),
            uncertainties = cms.vdouble(0.0296562368, 0.0296562368),
            upBounds = cms.vdouble(0.56, 1.5, 99999999),
            values = cms.vdouble(0.8871193652)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 0.0),
            uncertainties = cms.vdouble(0.0010278544, 0.0010278544),
            upBounds = cms.vdouble(0.85, 1.5, 28.0),
            values = cms.vdouble(0.902848697)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 28.0),
            uncertainties = cms.vdouble(0.0018686864, 0.0018686864),
            upBounds = cms.vdouble(0.85, 1.5, 31.0),
            values = cms.vdouble(0.9739174387)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 31.0),
            uncertainties = cms.vdouble(0.0010128057, 0.0010128057),
            upBounds = cms.vdouble(0.85, 1.5, 35.0),
            values = cms.vdouble(0.9756211698)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 35.0),
            uncertainties = cms.vdouble(0.0010379176, 0.0010379176),
            upBounds = cms.vdouble(0.85, 1.5, 40.0),
            values = cms.vdouble(0.9785859435)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 40.0),
            uncertainties = cms.vdouble(0.0010275549, 0.0010275549),
            upBounds = cms.vdouble(0.85, 1.5, 45.0),
            values = cms.vdouble(0.9814869681)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 45.0),
            uncertainties = cms.vdouble(0.0011650567, 0.0011650567),
            upBounds = cms.vdouble(0.85, 1.5, 50.0),
            values = cms.vdouble(0.9836603606)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 50.0),
            uncertainties = cms.vdouble(0.0010012441, 0.0010012441),
            upBounds = cms.vdouble(0.85, 1.5, 60.0),
            values = cms.vdouble(0.9808533747)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 60.0),
            uncertainties = cms.vdouble(0.0024188585, 0.0024188585),
            upBounds = cms.vdouble(0.85, 1.5, 70.0),
            values = cms.vdouble(0.9788313651)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 70.0),
            uncertainties = cms.vdouble(0.0012890816, 0.0012890816),
            upBounds = cms.vdouble(0.85, 1.5, 90.0),
            values = cms.vdouble(0.976605377)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.56, 0.0, 90.0),
            uncertainties = cms.vdouble(0.0022197084, 0.0022197084),
            upBounds = cms.vdouble(0.85, 1.5, 99999999),
            values = cms.vdouble(0.9667617117)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 0.0),
            uncertainties = cms.vdouble(0.0065966201, 0.0065966201),
            upBounds = cms.vdouble(999, 1.5, 28.0),
            values = cms.vdouble(0.8933536854)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 28.0),
            uncertainties = cms.vdouble(0.0017666493, 0.0017666493),
            upBounds = cms.vdouble(999, 1.5, 31.0),
            values = cms.vdouble(0.9973958724)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 31.0),
            uncertainties = cms.vdouble(0.001086051, 0.001086051),
            upBounds = cms.vdouble(999, 1.5, 35.0),
            values = cms.vdouble(0.9980479262)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 35.0),
            uncertainties = cms.vdouble(0.0010000106, 0.0010000106),
            upBounds = cms.vdouble(999, 1.5, 40.0),
            values = cms.vdouble(0.998728949)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001000066, 0.001000066),
            upBounds = cms.vdouble(999, 1.5, 45.0),
            values = cms.vdouble(0.9992636424)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 45.0),
            uncertainties = cms.vdouble(0.0010000824, 0.0010000824),
            upBounds = cms.vdouble(999, 1.5, 50.0),
            values = cms.vdouble(0.999468697)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 50.0),
            uncertainties = cms.vdouble(0.0010000075, 0.0010000075),
            upBounds = cms.vdouble(999, 1.5, 60.0),
            values = cms.vdouble(0.9995552559)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 60.0),
            uncertainties = cms.vdouble(0.0010531353, 0.0010531353),
            upBounds = cms.vdouble(999, 1.5, 70.0),
            values = cms.vdouble(0.9992541003)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 70.0),
            uncertainties = cms.vdouble(0.0010000525, 0.0010000525),
            upBounds = cms.vdouble(999, 1.5, 90.0),
            values = cms.vdouble(0.9996086647)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 90.0),
            uncertainties = cms.vdouble(0.0010000001, 0.0010000001),
            upBounds = cms.vdouble(999, 1.5, 99999999),
            values = cms.vdouble(0.9996779894)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0044630622, 0.0044630622),
            upBounds = cms.vdouble(0.85, 3.0, 28.0),
            values = cms.vdouble(0.6100544113)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 28.0),
            uncertainties = cms.vdouble(0.0041193336, 0.0041193336),
            upBounds = cms.vdouble(0.85, 3.0, 31.0),
            values = cms.vdouble(0.7427840769)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 31.0),
            uncertainties = cms.vdouble(0.0023197541, 0.0023197541),
            upBounds = cms.vdouble(0.85, 3.0, 35.0),
            values = cms.vdouble(0.7761341323)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 35.0),
            uncertainties = cms.vdouble(0.0018272149, 0.0018272149),
            upBounds = cms.vdouble(0.85, 3.0, 40.0),
            values = cms.vdouble(0.8117452882)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 40.0),
            uncertainties = cms.vdouble(0.0017371369, 0.0017371369),
            upBounds = cms.vdouble(0.85, 3.0, 45.0),
            values = cms.vdouble(0.831908844)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 45.0),
            uncertainties = cms.vdouble(0.0029028382, 0.0029028382),
            upBounds = cms.vdouble(0.85, 3.0, 50.0),
            values = cms.vdouble(0.8583582498)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 50.0),
            uncertainties = cms.vdouble(0.0067434212, 0.0067434212),
            upBounds = cms.vdouble(0.85, 3.0, 60.0),
            values = cms.vdouble(0.8736432627)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0088928808, 0.0088928808),
            upBounds = cms.vdouble(0.85, 3.0, 70.0),
            values = cms.vdouble(0.8907409748)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0083321492, 0.0083321492),
            upBounds = cms.vdouble(0.85, 3.0, 90.0),
            values = cms.vdouble(0.9046665266)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 90.0),
            uncertainties = cms.vdouble(0.0092567264, 0.0092567264),
            upBounds = cms.vdouble(0.85, 3.0, 99999999),
            values = cms.vdouble(0.9190711276)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0043867136, 0.0043867136),
            upBounds = cms.vdouble(0.9, 3.0, 28.0),
            values = cms.vdouble(0.8283101205)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 28.0),
            uncertainties = cms.vdouble(0.0024484718, 0.0024484718),
            upBounds = cms.vdouble(0.9, 3.0, 31.0),
            values = cms.vdouble(0.9538552575)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 31.0),
            uncertainties = cms.vdouble(0.0012894149, 0.0012894149),
            upBounds = cms.vdouble(0.9, 3.0, 35.0),
            values = cms.vdouble(0.9597166341)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 35.0),
            uncertainties = cms.vdouble(0.0016910488, 0.0016910488),
            upBounds = cms.vdouble(0.9, 3.0, 40.0),
            values = cms.vdouble(0.9617373097)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 40.0),
            uncertainties = cms.vdouble(0.0010003997, 0.0010003997),
            upBounds = cms.vdouble(0.9, 3.0, 45.0),
            values = cms.vdouble(0.9624428298)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 45.0),
            uncertainties = cms.vdouble(0.0015842487, 0.0015842487),
            upBounds = cms.vdouble(0.9, 3.0, 50.0),
            values = cms.vdouble(0.9581303007)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 50.0),
            uncertainties = cms.vdouble(0.0030254988, 0.0030254988),
            upBounds = cms.vdouble(0.9, 3.0, 60.0),
            values = cms.vdouble(0.9621293579)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0039064632, 0.0039064632),
            upBounds = cms.vdouble(0.9, 3.0, 70.0),
            values = cms.vdouble(0.967026223)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0031524223, 0.0031524223),
            upBounds = cms.vdouble(0.9, 3.0, 90.0),
            values = cms.vdouble(0.9721855102)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 1.5, 90.0),
            uncertainties = cms.vdouble(0.0031751105, 0.0031751105),
            upBounds = cms.vdouble(0.9, 3.0, 99999999),
            values = cms.vdouble(0.9753380476)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0010432162, 0.0010432162),
            upBounds = cms.vdouble(999, 3.0, 28.0),
            values = cms.vdouble(0.8582078363)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 28.0),
            uncertainties = cms.vdouble(0.0018317715, 0.0018317715),
            upBounds = cms.vdouble(999, 3.0, 31.0),
            values = cms.vdouble(0.9911788518)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 31.0),
            uncertainties = cms.vdouble(0.0011267834, 0.0011267834),
            upBounds = cms.vdouble(999, 3.0, 35.0),
            values = cms.vdouble(0.9961663139)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 35.0),
            uncertainties = cms.vdouble(0.001000539, 0.001000539),
            upBounds = cms.vdouble(999, 3.0, 40.0),
            values = cms.vdouble(0.9974520554)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 40.0),
            uncertainties = cms.vdouble(0.0011367326, 0.0011367326),
            upBounds = cms.vdouble(999, 3.0, 45.0),
            values = cms.vdouble(0.998387259)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 45.0),
            uncertainties = cms.vdouble(0.0010000889, 0.0010000889),
            upBounds = cms.vdouble(999, 3.0, 50.0),
            values = cms.vdouble(0.9988958563)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 50.0),
            uncertainties = cms.vdouble(0.0010002577, 0.0010002577),
            upBounds = cms.vdouble(999, 3.0, 60.0),
            values = cms.vdouble(0.9987919975)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 60.0),
            uncertainties = cms.vdouble(0.001040689, 0.001040689),
            upBounds = cms.vdouble(999, 3.0, 70.0),
            values = cms.vdouble(0.999279006)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0010003602, 0.0010003602),
            upBounds = cms.vdouble(999, 3.0, 90.0),
            values = cms.vdouble(0.999472035)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 90.0),
            uncertainties = cms.vdouble(0.0010000015, 0.0010000015),
            upBounds = cms.vdouble(999, 3.0, 99999999),
            values = cms.vdouble(0.9995989436)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 3.0, 0),
            uncertainties = cms.vdouble(1.0, 1.0),
            upBounds = cms.vdouble(999, 999, 999999),
            values = cms.vdouble(1.0)
        )
    ),
    variables = cms.vstring(
        'full5x5_r9', 
        'abs(superCluster.eta)', 
        'pt'
    )
)

process.tagsDumpConfig = cms.PSet(
    categories = cms.VPSet(),
    className = cms.untracked.string(''),
    classifierCfg = cms.PSet(
        categories = cms.VPSet()
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(False),
    dumpTrees = cms.untracked.bool(False),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(),
        dumpLHEInfo = cms.bool(False),
        extraFloats = cms.PSet(

        ),
        lhePartTable = cms.InputTag("lheInfoTable","LHEPart"),
        lheTable = cms.InputTag("lheInfoTable","LHE"),
        mcPu = cms.vdouble(),
        puBins = cms.vdouble(),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(False),
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    intLumi = cms.untracked.double(0),
    lumiWeight = cms.double(1.0),
    maxCandPerEvent = cms.int32(-1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$CLASSNAME_$SUBCAT_$LABEL'),
    processId = cms.string('Data'),
    processIndex = cms.int32(0),
    quietRooFit = cms.untracked.bool(False),
    src = cms.InputTag(""),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)

process.ak4CaloL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector")
)


process.ak4CaloL1FastL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloL6SLBCorrector")
)


process.ak4CaloL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloResidualCorrector")
)


process.ak4CaloL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAllCalo")
)


process.ak4CaloL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector")
)


process.ak4CaloL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloResidualCorrector")
)


process.ak4CaloL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4CaloL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector")
)


process.ak4CaloL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloL6SLBCorrector")
)


process.ak4CaloL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloResidualCorrector")
)


process.ak4CaloL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L2Relative')
)


process.ak4CaloL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L3Absolute')
)


process.ak4CaloL6SLBCorrector = cms.EDProducer("L6SLBCorrectorProducer",
    addMuonToJet = cms.bool(True),
    algorithm = cms.string(''),
    level = cms.string('L6SLB'),
    srcBTagInfoElectron = cms.InputTag("ak4CaloJetsSoftElectronTagInfos"),
    srcBTagInfoMuon = cms.InputTag("ak4CaloJetsSoftMuonTagInfos")
)


process.ak4CaloResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L2L3Residual')
)


process.ak4JPTL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4L1JPTFastjetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector")
)


process.ak4JPTL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4L1JPTFastjetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector", "ak4JPTResidualCorrector")
)


process.ak4JPTL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector")
)


process.ak4JPTL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector", "ak4JPTResidualCorrector")
)


process.ak4JPTL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector")
)


process.ak4JPTL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector", "ak4JPTResidualCorrector")
)


process.ak4JPTL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L2Relative')
)


process.ak4JPTL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L3Absolute')
)


process.ak4JPTResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L2L3Residual')
)


process.ak4L1JPTFastjetCorrector = cms.EDProducer("L1JPTOffsetCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L1JPTOffset'),
    offsetService = cms.InputTag("ak4CaloL1FastjetCorrector")
)


process.ak4L1JPTOffsetCorrector = cms.EDProducer("L1JPTOffsetCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L1JPTOffset'),
    offsetService = cms.InputTag("ak4CaloL1OffsetCorrector")
)


process.ak4PFCHSL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1FastjetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector")
)


process.ak4PFCHSL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1FastjetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector", "ak4PFCHSResidualCorrector")
)


process.ak4PFCHSL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFCHSL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1OffsetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector")
)


process.ak4PFCHSL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1OffsetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector", "ak4PFCHSResidualCorrector")
)


process.ak4PFCHSL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4PFCHSL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector")
)


process.ak4PFCHSL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector", "ak4PFCHSResidualCorrector")
)


process.ak4PFCHSL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L2Relative')
)


process.ak4PFCHSL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L3Absolute')
)


process.ak4PFCHSResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L2L3Residual')
)


process.ak4PFL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1FastjetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector")
)


process.ak4PFL1FastL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1FastjetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFL6SLBCorrector")
)


process.ak4PFL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1FastjetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFResidualCorrector")
)


process.ak4PFL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1OffsetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector")
)


process.ak4PFL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1OffsetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFResidualCorrector")
)


process.ak4PFL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4PFL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector")
)


process.ak4PFL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFL6SLBCorrector")
)


process.ak4PFL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFResidualCorrector")
)


process.ak4PFL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L2Relative')
)


process.ak4PFL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L3Absolute')
)


process.ak4PFL6SLBCorrector = cms.EDProducer("L6SLBCorrectorProducer",
    addMuonToJet = cms.bool(False),
    algorithm = cms.string(''),
    level = cms.string('L6SLB'),
    srcBTagInfoElectron = cms.InputTag("ak4PFJetsSoftElectronTagInfos"),
    srcBTagInfoMuon = cms.InputTag("ak4PFJetsSoftMuonTagInfos")
)


process.ak4PFPuppiL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1FastjetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector")
)


process.ak4PFPuppiL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1FastjetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector", "ak4PFPuppiResidualCorrector")
)


process.ak4PFPuppiL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFPuppiL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1OffsetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector")
)


process.ak4PFPuppiL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1OffsetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector", "ak4PFPuppiResidualCorrector")
)


process.ak4PFPuppiL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4PFPuppiL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector")
)


process.ak4PFPuppiL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector", "ak4PFPuppiResidualCorrector")
)


process.ak4PFPuppiL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L2Relative')
)


process.ak4PFPuppiL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L3Absolute')
)


process.ak4PFPuppiResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L2L3Residual')
)


process.ak4PFResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L2L3Residual')
)


process.ak4TrackL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4TrackL2RelativeCorrector", "ak4TrackL3AbsoluteCorrector")
)


process.ak4TrackL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4TRK'),
    level = cms.string('L2Relative')
)


process.ak4TrackL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4TRK'),
    level = cms.string('L3Absolute')
)


process.flashggDiPhotonMVA = cms.EDProducer("FlashggDiPhotonMVAProducer",
    BeamSpotSigma = cms.double(3.7),
    BeamSpotTag = cms.InputTag("offlineBeamSpot"),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    Version = cms.string('xgb'),
    VertexProbParamsConv = cms.vdouble(-0.045, -0.148, -0.328, -0.184),
    VertexProbParamsNoConv = cms.vdouble(-0.366, -0.126, -0.119, -0.091),
    diphotonMVAweightfile = cms.FileInPath('flashgg/Taggers/data/STXSmodels/altDiphoModel_IncUL2017.xml'),
    doSigmaMdecorr = cms.bool(True),
    sigmaMdecorrFile = cms.FileInPath('flashgg/Taggers/data/diphoMVA_sigmaMoMdecorr_split_Mgg40_180.root')
)


process.flashggDiPhotonSystematics = cms.EDProducer("FlashggDiPhotonSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleLowR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(),
            OverallRange = cms.string('full5x5_r9<0.96&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleHighR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(),
            OverallRange = cms.string('full5x5_r9>0.96&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleLowR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(),
            OverallRange = cms.string('full5x5_r9<0.96&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleHighR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(),
            OverallRange = cms.string('full5x5_r9>0.96&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_24Feb2020_runEtaR9Gain_v2_oldFormat'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('SigmaEOverESmearing'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(),
            OverallRange = cms.string('1'),
            PhotonMethodName = cms.string('FlashggPhotonSigEoverESmearingEGMTool')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggDifferentialPhoIdInputsCorrection")
)


process.flashggDifferentialPhoIdInputsCorrection = cms.EDProducer("FlashggDifferentialPhoIdInputsCorrector",
    chIso_corrector_config_EB = cms.PSet(
        chIsoWorst_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EB'),
            regr_output_scaling = cms.string('x[0]*(0.076982)+(0.088750)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtChosenVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtWorstVtx03'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EB_chIsoWorst.xml')
        ),
        chIsoWorst_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EB_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtChosenVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIsoWorst_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalTailRegressor_EB_chIsoWorst.xml')
        ),
        chIso_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB'),
            regr_output_scaling = cms.string('x[0]*(0.070336)+(0.033092)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtChosenVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtWorstVtx03'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EB_chIso.xml')
        ),
        chIso_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtWorstVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIso_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalTailRegressor_EB_chIso.xml')
        ),
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB_3Cat_data'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/data_clf_3Cat_EB_chIso_chIsoWorst.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB_3Cat_mc'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/mc_clf_3Cat_EB_chIso_chIsoWorst.xml')
        )
    ),
    chIso_corrector_config_EE = cms.PSet(
        chIsoWorst_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EE'),
            regr_output_scaling = cms.string('x[0]*(0.069375)+(-0.012103)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtChosenVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtWorstVtx03'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EE_chIsoWorst.xml')
        ),
        chIsoWorst_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EE_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtChosenVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIsoWorst_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalTailRegressor_EE_chIsoWorst.xml')
        ),
        chIso_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE'),
            regr_output_scaling = cms.string('x[0]*(0.053903)+(0.005629)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtChosenVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtWorstVtx03'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EE_chIso.xml')
        ),
        chIso_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtWorstVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIso_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalTailRegressor_EE_chIso.xml')
        ),
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE_3Cat_data'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/data_clf_3Cat_EE_chIso_chIsoWorst.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE_3Cat_mc'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/mc_clf_3Cat_EE_chIso_chIsoWorst.xml')
        )
    ),
    correctIsolations = cms.bool(True),
    correctPreshower = cms.bool(False),
    correctShowerShapes = cms.bool(True),
    diphotonSrc = cms.InputTag("flashggDiPhotons"),
    effAreasConfigFile = cms.FileInPath('RecoEgamma/PhotonIdentification/data/Fall17/effAreaPhotons_cone03_pfPhotons_90percentBased_TrueVtx.txt'),
    etaWidth_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_etaWidth_EB'),
        regr_output_scaling = cms.string('x[0]*(0.000298)+(-0.000007)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EB_etaWidth.xml')
    ),
    etaWidth_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_etaWidth_EE'),
        regr_output_scaling = cms.string('x[0]*(0.000450)+(0.000263)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EE_etaWidth.xml')
    ),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(),
        dumpLHEInfo = cms.bool(False),
        extraFloats = cms.PSet(

        ),
        lhePartTable = cms.InputTag("lheInfoTable","LHEPart"),
        lheTable = cms.InputTag("lheInfoTable","LHE"),
        mcPu = cms.vdouble(),
        puBins = cms.vdouble(),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(False),
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    is2017 = cms.bool(True),
    phiWidth_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_phiWidth_EB'),
        regr_output_scaling = cms.string('x[0]*(0.001519)+(0.000486)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EB_phiWidth.xml')
    ),
    phiWidth_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_phiWidth_EE'),
        regr_output_scaling = cms.string('x[0]*(0.002077)+(0.001219)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EE_phiWidth.xml')
    ),
    phoIsoCutoff = cms.double(2.5),
    phoIsoPtScalingCoeff = cms.vdouble(0.0053, 0.0034),
    phoIso_corrector_config_EB = cms.PSet(
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB_p0t_data'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/data_clf_p2t_EB_phoIso.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB_p0t_mc'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/mc_clf_p2t_EB_phoIso.xml')
        ),
        morphing = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB'),
            regr_output_scaling = cms.string('x[0]*(0.083284)+(0.044500)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfPhoIso03'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EB_phoIso.xml')
        ),
        peak2tail = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_rnd")'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalTailRegressor_EB_phoIso.xml')
        )
    ),
    phoIso_corrector_config_EE = cms.PSet(
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE_p0t_data'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/data_clf_p2t_EE_phoIso.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE_p0t_mc'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/mc_clf_p2t_EE_phoIso.xml')
        ),
        morphing = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE'),
            regr_output_scaling = cms.string('x[0]*(0.036594)+(-0.005994)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfPhoIso03'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EE_phoIso.xml')
        ),
        peak2tail = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_rnd")'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalTailRegressor_EE_phoIso.xml')
        )
    ),
    photonIdMVAweightfile_EB = cms.FileInPath('flashgg/MicroAOD/data/PhoID_barrel_UL2017_GJetMC_SATrain_nTree2k_LR_0p1_13052020_BDTG.weights.xml'),
    photonIdMVAweightfile_EE = cms.FileInPath('flashgg/MicroAOD/data/PhoID_endcap_UL2017_GJetMC_SATrain_nTree2k_LR_0p1_13052020_BDTG.weights.xml'),
    r9_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_r9_EB'),
        regr_output_scaling = cms.string('x[0]*(0.008904)+(-0.003140)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EB_r9.xml')
    ),
    r9_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_r9_EE'),
        regr_output_scaling = cms.string('x[0]*(0.013703)+(-0.007244)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EE_r9.xml')
    ),
    reRunRegression = cms.bool(False),
    regressionConfig = cms.PSet(
        autoDetectBunchSpacing = cms.bool(False),
        eOverP_ECALTRKThr = cms.double(0.025),
        electron_config = cms.PSet(
            regressionKey = cms.vstring(
                'electron_eb_ECALonly_lowpt', 
                'electron_eb_ECALonly', 
                'electron_ee_ECALonly_lowpt', 
                'electron_ee_ECALonly', 
                'electron_eb_ECALTRK_lowpt', 
                'electron_eb_ECALTRK', 
                'electron_ee_ECALTRK_lowpt', 
                'electron_ee_ECALTRK'
            ),
            uncertaintyKey = cms.vstring(
                'electron_eb_ECALonly_lowpt_var', 
                'electron_eb_ECALonly_var', 
                'electron_ee_ECALonly_lowpt_var', 
                'electron_ee_ECALonly_var', 
                'electron_eb_ECALTRK_lowpt_var', 
                'electron_eb_ECALTRK_var', 
                'electron_ee_ECALTRK_lowpt_var', 
                'electron_ee_ECALTRK_var'
            )
        ),
        epDiffSig_ECALTRKThr = cms.double(15.0),
        epSig_ECALTRKThr = cms.double(10.0),
        forceHighEnergyEcalTrainingIfSaturated = cms.bool(True),
        highEnergy_ECALTRKThr = cms.double(200.0),
        lowEnergy_ECALTRKThr = cms.double(50.0),
        lowEnergy_ECALonlyThr = cms.double(99999.0),
        manualBunchSpacing = cms.int32(25),
        modifierName = cms.string('EGRegressionModifierV2'),
        photon_config = cms.PSet(
            regressionKey = cms.vstring(
                'photon_eb_ECALonly_lowpt', 
                'photon_eb_ECALonly', 
                'photon_ee_ECALonly_lowpt', 
                'photon_ee_ECALonly'
            ),
            uncertaintyKey = cms.vstring(
                'photon_eb_ECALonly_lowpt_var', 
                'photon_eb_ECALonly_var', 
                'photon_ee_ECALonly_lowpt_var', 
                'photon_ee_ECALonly_var'
            )
        ),
        rhoCollection = cms.InputTag("fixedGridRhoFastjetAll"),
        vertexCollection = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    rhoFixedGridCollection = cms.InputTag("fixedGridRhoAll"),
    s4_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_s4_EB'),
        regr_output_scaling = cms.string('x[0]*(0.006374)+(-0.002432)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EB_s4.xml')
    ),
    s4_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_s4_EE'),
        regr_output_scaling = cms.string('x[0]*(0.014027)+(-0.009796)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EE_s4.xml')
    ),
    sieie_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_sieie_EB'),
        regr_output_scaling = cms.string('x[0]*(0.000092)+(-0.000018)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EB_sieie.xml')
    ),
    sieie_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_sieie_EE'),
        regr_output_scaling = cms.string('x[0]*(0.000427)+(0.000228)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EE_sieie.xml')
    ),
    sieip_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_sieip_EB'),
        regr_output_scaling = cms.string('x[0]*(0.000001)+(-0.000000)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EB_sieip.xml')
    ),
    sieip_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_sieip_EE'),
        regr_output_scaling = cms.string('x[0]*(0.000019)+(-0.000010)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017_Legacy/weights_finalRegressor_EE_sieip.xml')
    )
)


process.flashggElectronSystematics = cms.EDProducer("FlashggElectronEffSystematicProducer",
    SystMethods = cms.VPSet(),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggSelectedElectrons")
)


process.flashggGluGluHMVA = cms.EDProducer("FlashggGluGluHMVAProducer",
    DiPhotonMVATag = cms.InputTag("flashggDiPhotonMVA"),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    DrJetPhoton = cms.double(0.4),
    JetIDLevel = cms.string('Tight2017'),
    MVAMethod = cms.string('Multi'),
    MinDijetMinv = cms.double(0.0),
    UseJetID = cms.bool(True),
    UsePuJetID = cms.bool(False),
    ggHMVAweightfile = cms.FileInPath('flashgg/Taggers/data/STXSmodels/nClassesModel_IncUL2017.xml'),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    merge3rdJet = cms.bool(False),
    pujidWpPtBin1 = cms.vdouble(0.69, -0.35, -0.26, -0.21),
    pujidWpPtBin2 = cms.vdouble(0.86, -0.1, -0.05, -0.01),
    rmsforwardCut = cms.double(3.0),
    thirdJetDRCut = cms.double(1.8)
)


process.flashggJetSystematics0 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","0")
)


process.flashggJetSystematics1 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","1")
)


process.flashggJetSystematics10 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","10")
)


process.flashggJetSystematics11 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","11")
)


process.flashggJetSystematics2 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","2")
)


process.flashggJetSystematics3 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","3")
)


process.flashggJetSystematics4 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","4")
)


process.flashggJetSystematics5 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","5")
)


process.flashggJetSystematics6 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","6")
)


process.flashggJetSystematics7 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","7")
)


process.flashggJetSystematics8 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","8")
)


process.flashggJetSystematics9 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(cms.PSet(
        ApplyCentralValue = cms.bool(True),
        Debug = cms.untracked.bool(False),
        JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3ResidualCorrector"),
        Label = cms.string('JEC'),
        MethodName = cms.string('FlashggJetEnergyCorrector'),
        NSigmas = cms.vint32(),
        OverallRange = cms.string('abs(eta)<5.0'),
        SetupUncertainties = cms.bool(False),
        SourceName = cms.string('notused'),
        TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/RegroupedV2_Summer19UL17_V5_MC_UncertaintySources_AK4PFchs.txt'),
        UseTextFile = cms.bool(False)
    )),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","9")
)


process.flashggMetSystematics = cms.EDProducer("FlashggMetSmearSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metJecUncertainty'),
            MethodName = cms.string('FlashggMetJecSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metJerUncertainty'),
            MethodName = cms.string('FlashggMetJerSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metPhoUncertainty'),
            MethodName = cms.string('FlashggMetPhoSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metUncUncertainty'),
            MethodName = cms.string('FlashggMetUncSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggMets")
)


process.flashggMuonSystematics = cms.EDProducer("FlashggMuonEffSystematicProducer",
    SystMethods = cms.VPSet(),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggSelectedMuons")
)


process.flashggPrefireDiPhotons = cms.EDProducer("FlashggPrefireDiPhotonProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotonSystematics"),
    ECALFileName = cms.FileInPath('flashgg/Taggers/data/L1PrefiringMaps.root'),
    MuonFileName = cms.FileInPath('flashgg/Taggers/data/L1MuonPrefiringParametriations.root'),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    applyToCentral = cms.bool(False),
    dataeraEcal = cms.string('UL2017BtoF'),
    dataeraMuon = cms.string('20172018'),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    isECALRelevant = cms.bool(True)
)


process.flashggSigmaMoMpToMTag = cms.EDProducer("FlashggSigmaMpTTagPreCleanerProducer",
    BoundariesSigmaMoM = cms.vdouble(0.0, 0.00841, 0.0116, 0.0298),
    CompositeCandidateTags = cms.PSet(

    ),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireScaledPtCuts = cms.bool(True),
    SystLabel = cms.string('')
)


process.flashggStageOneCombinedTag = cms.EDProducer("FlashggStageOneCombinedTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GluGluHMVAResultTag = cms.InputTag("flashggGluGluHMVA"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA"),
    VHhadMVAResultTag = cms.InputTag("flashggVHhadMVA"),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    rawDijetBounds = cms.vdouble(
        0.438, 0.323, 0.56, 0.405, 0.445, 
        0.303, 0.537, 0.393, 0.461, 0.316, 
        0.631, 0.575
    ),
    rawDiphoBounds = cms.vdouble(
        0.799, 0.705, 0.548, 0.851, 0.793, 
        0.599, 0.853, 0.79, 0.686, 0.868, 
        0.81, 0.729, 0.926, 0.904, 0.815, 
        0.853, 0.782, 0.659, 0.893, 0.847, 
        0.732, 0.928, 0.886, 0.824, 0.945, 
        0.857, 0.905, 0.863, 0.842, 0.798, 
        0.815, 0.83, 0.657, 0.783, 0.778, 
        0.726, 0.687, 0.637, 0.813, 0.728, 
        0.611, 0.55, 0.837, 0.827
    ),
    rawGghBounds = cms.vdouble(
        0.544, 0.687, 0.598, 0.611, 0.636, 
        0.613, 0.601, 0.666, 0.488, 0.62, 
        0.616, 0.303
    ),
    rawVhHadBounds = cms.vdouble(0.835, 0.534),
    useMultiClass = cms.bool(True)
)


process.flashggSystTagMerger = cms.EDProducer("TagMerger",
    src = cms.VInputTag("flashggTagSorter")
)


process.flashggTHQLeptonicTag = cms.EDProducer("FlashggTHQLeptonicTagProducer",
    Boundaries = cms.vdouble(
        -0.5, -0.45, -0.4, -0.35, -0.3, 
        -0.25, -0.2, -0.15, -0.1, -0.05, 
        0, 0.05, 0.1, 0.15, 0.2, 
        0.25, 0.3, 0.35, 0.4, 0.45
    ),
    DeltaRTrkElec = cms.double(0.35),
    DeltaRbjetfwdjet = cms.double(0.4),
    DeltaRtHchainfwdjet = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAMethod = cms.string('BDT'),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.3),
    MVAThreshold_tHqVsNonHiggsBkg = cms.double(0.04),
    MVAThreshold_tHqVsttHBDT = cms.double(-0.02),
    MVAThreshold_tHqVsttHDNN = cms.double(0.25),
    MVAweight_tHqVsNonHiggsBkg = cms.FileInPath('flashgg/Taggers/data/TMVA_THQLeptonicTag_tHq_Vs_NonPeakingBkg_BDT_17_v2.weights.xml'),
    MVAweight_tHqVsttHBDT = cms.FileInPath('flashgg/Taggers/data/TMVA_THQLeptonicTag_tHq_Vs_ttH_BDT.weights.xml'),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.7),
    SystLabel = cms.string(''),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepCSV'),
    bjetsNumberThreshold = cms.double(1.0),
    debug = cms.bool(False),
    deltaRJetLeadPhoThreshold = cms.double(0.4),
    deltaRJetLepThreshold = cms.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.double(0.4),
    deltaRLepPhoThreshold = cms.double(0.4),
    deltaRPhoElectronThreshold = cms.double(0.4),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.4),
    electronPtThreshold = cms.double(10.0),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(5),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(1.0),
    leadPhoOverMassThreshold = cms.double(0.33),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    muonPtThreshold = cms.double(5.0),
    processId = cms.string('Data'),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    tthVstHDNN_global_mean = cms.vdouble(
        0.000872488424648, 0.00181764841545, 0.0039372346364, 0.00293846987188, 1.13397824764, 
        0.545903623104, 0.901656806469, 0.574115335941, 4.26857566833, 0.0745667442679, 
        0.0685612782836, 0.0746329054236, 0.00108663761057, 1.36858439445, 1.76910328865, 
        0.491233110428, 0.141329720616, 3.79498243332, 0.976810276508, 0.0907413586974, 
        0.000131546359626, 2.37732553482, 3.99278855324
    ),
    tthVstHDNN_global_stddev = cms.vdouble(
        0.961749851704, 1.01643288136, 1.8153655529, 1.81395637989, 0.76128757, 
        0.327195465565, 0.161034047604, 0.447774082422, 0.786187469959, 1.86160492897, 
        0.252706587315, 0.26279810071, 0.88299882412, 1.11115789413, 0.749173998833, 
        1.34055995941, 3.2089304924, 1.70906722546, 0.368967741728, 0.995874464512, 
        0.259301453829, 1.14366912842, 0.620222449303
    ),
    tthVstHDNN_object_mean = cms.vdouble(
        4.09283996184, 0.00203595840898, -0.0070924805625, 4.90515218074, -0.328717589356, 
        -0.467018516104, -0.382964227324, -0.29098795085, -1.47064665613
    ),
    tthVstHDNN_object_stddev = cms.vdouble(
        0.703621287794, 1.66649618278, 1.81138677516, 1.00716173697, 5.69205266676, 
        5.67511818496, 5.68345978834, 5.69381117947, 1.02384447796
    ),
    tthVstHDNNfile = cms.FileInPath('flashgg/Taggers/data/Leptonic_ttHLeptonic_ttH_vs_tH_legacy_v1.0_ttH_vs_tH_26Nov2020_weights.pb'),
    use_MVAs = cms.bool(True),
    use_tthVstHBDT = cms.bool(False),
    use_tthVstHDNN = cms.bool(True)
)


process.flashggTTHDiLeptonTag = cms.EDProducer("FlashggTTHDiLeptonTagProducer",
    CutBasedDiphoId = cms.vdouble(
        0.4, 0.3, 0.0, -0.5, 2.0, 
        2.5
    ),
    DeltaRTrkEle = cms.double(0.35),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    EleEtaCuts = cms.vdouble(1.4442, 1.566, 2.5),
    ElePhotonDrCut = cms.double(0.2),
    ElePhotonZMassCut = cms.double(5),
    ElePtCut = cms.double(10),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    LeptonsZMassCut = cms.double(5),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.5),
    MVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVAClassification_BDT_training_v2.json.weights.xml'),
    MetTag = cms.InputTag("flashggMetSystematics"),
    MuonEtaCut = cms.double(2.4),
    MuonIsoCut = cms.double(0.25),
    MuonPhotonDrCut = cms.double(0.2),
    MuonPtCut = cms.double(5),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.2),
    SystLabel = cms.string(''),
    UseCutBasedDiphoId = cms.bool(False),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepCSV'),
    bjetsNumberThreshold = cms.double(1.0),
    debug = cms.bool(False),
    deltaRJetLeadPhoThreshold = cms.double(0.4),
    deltaRJetLepton = cms.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.double(0.4),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(1.0),
    leadPhoOverMassThreshold = cms.double(0.33),
    leadingJetPtThreshold = cms.double(0),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25)
)


process.flashggTTHHadronicTag = cms.EDProducer("FlashggTTHHadronicTagProducer",
    Boundaries = cms.vdouble(0.986025, 0.9948537, 0.9983046, 0.9990729),
    Boundaries_pt1 = cms.vdouble(0.9705986, 0.99322987, 0.994506),
    Boundaries_pt2 = cms.vdouble(0.9788471, 0.9954657, 0.99611914),
    Boundaries_pt3 = cms.vdouble(0.96859723, 0.9872348, 0.99252445, 0.9961255),
    Boundaries_pt4 = cms.vdouble(0.9824722, 0.99405247, 0.99727315),
    Boundaries_pt5 = cms.vdouble(0.972507, 0.99530387),
    DeltaRTrkEle = cms.double(0.0),
    DiPhotonName = cms.string('flashggPreselectedDiPhotons'),
    DiPhotonSuffixes = cms.vstring(),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    EleEtaCuts = cms.vdouble(1.4442, 1.566, 2.5),
    ElePhotonDrCut = cms.double(0.0),
    ElePhotonZMassCut = cms.double(5),
    ElePtCut = cms.double(10),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    JetsCollSize = cms.uint32(12),
    JetsName = cms.string('flashggUnpackedJets'),
    JetsSuffixes = cms.vstring(),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAMethod = cms.string('BDT'),
    MVAResultName = cms.string('flashggDiPhotonMVA'),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVATTHHMVAThreshold = cms.double(-1.0),
    MVAThreshold = cms.double(-1.0),
    MetName = cms.string('flashggMets'),
    MetSuffixes = cms.vstring(),
    ModifySystematicsWorkflow = cms.bool(True),
    MuonEtaCut = cms.double(2.4),
    MuonIsoCut = cms.double(0.25),
    MuonPhotonDrCut = cms.double(0.0),
    MuonPtCut = cms.double(5),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.7),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    STXSPtBoundaries_pt1 = cms.vdouble(0, 60),
    STXSPtBoundaries_pt2 = cms.vdouble(60, 120),
    STXSPtBoundaries_pt3 = cms.vdouble(120, 200),
    STXSPtBoundaries_pt4 = cms.vdouble(200, 300),
    STXSPtBoundaries_pt5 = cms.vdouble(300, 13001),
    SystLabel = cms.string(''),
    SystematicsJetsName = cms.string('flashggJetSystematics'),
    SystematicsMetName = cms.string('flashggMetSystematics'),
    UseLargeMVAs = cms.bool(True),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    applyMETfilters = cms.bool(False),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepJet'),
    bjetsLooseNumberTTHHMVAThreshold = cms.int32(1),
    bjetsLooseNumberThreshold = cms.int32(0),
    bjetsNumberTTHHMVAThreshold = cms.int32(0),
    bjetsNumberThreshold = cms.int32(1),
    dRJetPhoLeadCut = cms.double(0.4),
    dRJetPhoSubleadCut = cms.double(0.4),
    debug = cms.bool(False),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(25.0),
    jetsNumberTTHHMVAThreshold = cms.int32(3),
    jetsNumberThreshold = cms.int32(5),
    leadPhoOverMassTTHHMVAThreshold = cms.double(0.33),
    leadPhoOverMassThreshold = cms.double(0.33),
    leadPhoPtThreshold = cms.double(20),
    leadPhoUseVariableThreshold = cms.bool(True),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    secondMaxBTagTTHHMVAThreshold = cms.double(0.0),
    subleadPhoOverMassThreshold = cms.double(0.25),
    subleadPhoPtThreshold = cms.double(20),
    subleadPhoUseVariableThreshold = cms.bool(True),
    topTaggerXMLfile = cms.FileInPath('flashgg/Taggers/data/resTop_xgb_csv_order_deepCTag.xml'),
    tthMVA_RunII_weightfile = cms.FileInPath('flashgg/Taggers/data/Hadronic_legacy_v1.1_27Nov2020_bdt.xml'),
    tthMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVAClassification_tth_hadronic_2017Data_30vars_v0.weights.xml'),
    tthVsDiphoDNN_global_mean = cms.vdouble(
        0.00200201291591, 0.00326460693032, 0.00507123488933, 0.00330276112072, 0.838615059853, 
        0.434823989868, 0.879874408245, 0.509138643742, 3.58630275726, 0.0715009942651, 
        0.0829438641667, 0.0888994038105, 0.00244060205296, 0.868660628796, 2.19320940971, 
        0.345182657242, 0.130756169558, 4.4248008728
    ),
    tthVsDiphoDNN_global_stddev = cms.vdouble(
        1.12390947342, 1.1713514328, 1.81168878078, 1.81438589096, 0.466888219118, 
        0.196083754301, 0.180743560195, 0.46649491787, 0.774844765663, 1.88338124752, 
        0.275797337294, 0.284598469734, 1.0253392458, 0.718299031258, 0.697776973248, 
        0.306316703558, 0.194912552834, 1.5402534008
    ),
    tthVsDiphoDNN_object_mean = cms.vdouble(
        4.15155243549, -0.000547756502767, -0.00484282656275, 4.67589039906, 0.112989260556, 
        -0.00139396272486, 0.118516289872, 0.222366902028
    ),
    tthVsDiphoDNN_object_stddev = cms.vdouble(
        0.66453367065, 1.1888069612, 1.81251328014, 0.774415070847, 2.38213826154, 
        2.3719463663, 2.37648024512, 2.38129618004
    ),
    tthVsDiphoDNNfile = cms.FileInPath('flashgg/Taggers/data/Hadronic_ttHHadronic_ttH_vs_dipho_legacy_v1.1_27Nov2020_weights.pb'),
    tthVsttGGDNN_global_mean = cms.vdouble(
        0.00213961815462, 0.00298566999845, 0.00600255606696, 0.00476527493447, 0.956877171993, 
        0.481997877359, 0.876397490501, 0.474679201841, 3.83191990852, 0.0944750607014, 
        0.0669308379292, 0.0732532516122, 0.00251545617357, 1.08534109592, 1.95843648911, 
        0.578163385391, 0.240440413356, 5.42584228516
    ),
    tthVsttGGDNN_global_stddev = cms.vdouble(
        0.963112533092, 1.0156853199, 1.81193709373, 1.81504571438, 0.551710546017, 
        0.241049021482, 0.197582498193, 0.495335012674, 0.80304402113, 1.86385369301, 
        0.249902203679, 0.260551720858, 0.869121074677, 0.836461424828, 0.710768520832, 
        0.251470953226, 0.233766004443, 1.55464422703
    ),
    tthVsttGGDNN_object_mean = cms.vdouble(
        4.22262835198, 0.000521625904216, -0.00635445751776, 4.70246354868, 0.161081683248, 
        -0.000800826223539, 0.118139575979, 0.206985490746
    ),
    tthVsttGGDNN_object_stddev = cms.vdouble(
        0.650529027428, 1.12845552877, 1.81274173341, 0.755573804391, 2.52039949046, 
        2.50651124404, 2.51128076263, 2.51602464596
    ),
    tthVsttGGDNNfile = cms.FileInPath('flashgg/Taggers/data/Hadronic_ttHHadronic_ttH_vs_ttGG_legacy_v1.1_27Nov2020_weights.pb'),
    useTTHHadronicMVA = cms.bool(True)
)


process.flashggTTHLeptonicTag = cms.EDProducer("FlashggTTHLeptonicTagProducer",
    CutBasedDiphoId = cms.vdouble(
        0.4, 0.3, 0.0, -0.5, 2.0, 
        2.5
    ),
    DeltaRTrkEle = cms.double(0.35),
    DiLeptonJetThreshold = cms.double(0),
    DiLeptonMVAThreshold = cms.double(-999),
    DiLeptonbJetThreshold = cms.double(1),
    DiPhotonName = cms.string('flashggPreselectedDiPhotons'),
    DiPhotonSuffixes = cms.vstring(),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    EleEtaCuts = cms.vdouble(1.4442, 1.566, 2.5),
    ElePhotonDrCut = cms.double(0.2),
    ElePhotonZMassCut = cms.double(5),
    ElePtCut = cms.double(10),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    JetsCollSize = cms.uint32(12),
    JetsName = cms.string('flashggUnpackedJets'),
    JetsSuffixes = cms.vstring(),
    LeptonsZMassCut = cms.double(5),
    MVAResultName = cms.string('flashggDiPhotonMVA'),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.vdouble(0.8997816, 0.95635754, 0.9725133, 0.9870608),
    MVAThreshold_pt1 = cms.vdouble(0.75, 0.9259551, 0.9577374),
    MVAThreshold_pt2 = cms.vdouble(0.9, 0.9533934, 0.96331936),
    MVAThreshold_pt3 = cms.vdouble(0.9199876, 0.94682026),
    MVAThreshold_pt4 = cms.vdouble(0.9089704),
    MVAThreshold_pt5 = cms.vdouble(0.6),
    MVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVAClassification_BDT_training_v2.json.weights.xml'),
    MaxNLep = cms.int32(10),
    MetName = cms.string('flashggMets'),
    MetSuffixes = cms.vstring(),
    MetTag = cms.InputTag("flashggMetSystematics"),
    MinNLep = cms.int32(1),
    ModifySystematicsWorkflow = cms.bool(True),
    MuonEtaCut = cms.double(2.4),
    MuonIsoCut = cms.double(0.25),
    MuonPhotonDrCut = cms.double(0.2),
    MuonPtCut = cms.double(5),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.7),
    STXSPtBoundaries_pt1 = cms.vdouble(0, 60),
    STXSPtBoundaries_pt2 = cms.vdouble(60, 120),
    STXSPtBoundaries_pt3 = cms.vdouble(120, 200),
    STXSPtBoundaries_pt4 = cms.vdouble(200, 300),
    STXSPtBoundaries_pt5 = cms.vdouble(200, 13001),
    SplitDiLeptEv = cms.bool(True),
    SystLabel = cms.string(''),
    SystematicsJetsName = cms.string('flashggJetSystematics'),
    SystematicsMetName = cms.string('flashggMetSystematics'),
    UseCutBasedDiphoId = cms.bool(False),
    UseLargeMVAs = cms.bool(True),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepJet'),
    bjetsNumberThreshold = cms.double(0.0),
    debug = cms.bool(False),
    deltaRJetLeadPhoThreshold = cms.double(0.4),
    deltaRJetLepton = cms.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.double(0.4),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(5.0),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(1.0),
    leadPhoOverMassThreshold = cms.double(0.33),
    leadingJetPtThreshold = cms.double(0),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    topTaggerXMLfile = cms.FileInPath('flashgg/Taggers/data/resTop_xgb_csv_order_deepCTag.xml'),
    tthMVA_RunII_weightfile = cms.FileInPath('flashgg/Taggers/data/Leptonic_legacy_v1.1_27Nov2020_bdt.xml'),
    tthVstHDNN_global_mean = cms.vdouble(
        0.000872488424648, 0.00181764841545, 0.0039372346364, 0.00293846987188, 1.13397824764, 
        0.545903623104, 0.901656806469, 0.574115335941, 4.26857566833, 0.0745667442679, 
        0.0685612782836, 0.0746329054236, 0.00108663761057, 1.36858439445, 1.76910328865, 
        0.491233110428, 0.141329720616, 3.79498243332, 0.976810276508, 0.0907413586974, 
        0.000131546359626, 2.37732553482, 3.99278855324
    ),
    tthVstHDNN_global_stddev = cms.vdouble(
        0.961749851704, 1.01643288136, 1.8153655529, 1.81395637989, 0.76128757, 
        0.327195465565, 0.161034047604, 0.447774082422, 0.786187469959, 1.86160492897, 
        0.252706587315, 0.26279810071, 0.88299882412, 1.11115789413, 0.749173998833, 
        1.34055995941, 3.2089304924, 1.70906722546, 0.368967741728, 0.995874464512, 
        0.259301453829, 1.14366912842, 0.620222449303
    ),
    tthVstHDNN_object_mean = cms.vdouble(
        4.09283996184, 0.00203595840898, -0.0070924805625, 4.90515218074, -0.328717589356, 
        -0.467018516104, -0.382964227324, -0.29098795085, -1.47064665613
    ),
    tthVstHDNN_object_stddev = cms.vdouble(
        0.703621287794, 1.66649618278, 1.81138677516, 1.00716173697, 5.69205266676, 
        5.67511818496, 5.68345978834, 5.69381117947, 1.02384447796
    ),
    tthVstHDNNfile = cms.FileInPath('flashgg/Taggers/data/Leptonic_ttHLeptonic_ttH_vs_tH_legacy_v1.0_ttH_vs_tH_26Nov2020_weights.pb'),
    tthVstHThreshold = cms.double(0.15),
    tthVsttGGDNN_global_mean = cms.vdouble(
        0.00289006624371, 0.00252656033263, -0.00328253302723, -0.00131549197249, 0.945346772671, 
        0.478439480066, 0.888769447803, 0.516402244568, 4.25482416153, 0.066611148417, 
        0.0704830288887, 0.0752918273211, 0.00272821611725, 1.06785535812, 1.96958696842, 
        0.548121452332, 0.20707167685, 3.96414113045, 1.00267279148
    ),
    tthVsttGGDNN_global_stddev = cms.vdouble(
        0.959898531437, 1.01219809055, 1.81516301632, 1.81189739704, 0.529783427715, 
        0.232645764947, 0.177278995514, 0.47642442584, 0.743276596069, 1.84162127972, 
        0.255959331989, 0.263861656189, 0.864474594593, 0.809140563011, 0.707989037037, 
        0.274789184332, 0.235440462828, 1.5348328352, 0.400639981031
    ),
    tthVsttGGDNN_object_mean = cms.vdouble(
        4.12676625716, 0.000377821238415, -0.00595723714464, 4.60796668204, -0.278498873783, 
        -0.432758588304, -0.34534971924, -0.293425268096, -1.47868881192
    ),
    tthVsttGGDNN_object_stddev = cms.vdouble(
        0.686251800973, 1.13302942345, 1.81278206234, 0.787140464165, 2.33586997878, 
        2.29173122735, 2.31228841429, 2.32622114222, 1.0176392278
    ),
    tthVsttGGDNNfile = cms.FileInPath('flashgg/Taggers/data/Leptonic_ttHLeptonic_ttH_vs_ttGG_legacy_v1.1_27Nov2020_weights.pb')
)


process.flashggTagSorter = cms.EDProducer("FlashggTagSorter",
    AddTruthInfo = cms.bool(True),
    BlindedSelectionPrintout = cms.bool(False),
    CreateNoTag = cms.bool(True),
    Debug = cms.untracked.bool(False),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0bin = cms.InputTag("rivetProducerHTXS","stage0bin"),
        stage1bin = cms.InputTag("rivetProducerHTXS","stage1bin")
    ),
    MassCutLower = cms.double(100),
    MassCutUpper = cms.double(180.0),
    MaxObjectWeightException = cms.double(10.0),
    MaxObjectWeightWarning = cms.double(2.5),
    MinObjectWeightException = cms.double(0.0),
    MinObjectWeightWarning = cms.double(0.4),
    NNLOPSWeightFile = cms.FileInPath('flashgg/Taggers/data/NNLOPS_reweight.root'),
    SetHTXSinfo = cms.bool(True),
    StoreOtherTagInfo = cms.bool(False),
    TagPriorityRanges = cms.VPSet(
        cms.PSet(
            TagName = cms.InputTag("flashggTHQLeptonicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggTTHLeptonicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggZHLeptonicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggWHLeptonicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggTTHHadronicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggVHMetTag")
        )
    ),
    applyNNLOPSweight = cms.bool(True),
    isGluonFusion = cms.bool(False)
)


process.flashggUnpackedJets = cms.EDProducer("FlashggVectorVectorJetUnpacker",
    JetsTag = cms.InputTag("flashggFinalJets"),
    NCollections = cms.uint32(12)
)


process.flashggUntagged = cms.EDProducer("FlashggUntaggedTagProducer",
    Boundaries = cms.vdouble(-0.405, 0.204, 0.564, 0.864),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireScaledPtCuts = cms.bool(True),
    SystLabel = cms.string('')
)


process.flashggVBFDiPhoDiJetMVA = cms.EDProducer("FlashggVBFDiPhoDiJetMVAProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    UseLegacyMVA = cms.bool(False),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA"),
    vbfDiPhoDiJetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/sklearn_combined_moriond17_v4.xml')
)


process.flashggVBFMVA = cms.EDProducer("FlashggVBFMVAProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    DrJetPhoton = cms.double(0.4),
    JetIDLevel = cms.string('Tight2017'),
    MVAMethod = cms.string('Multi'),
    MinDijetMinv = cms.double(0.0),
    UseJetID = cms.bool(True),
    UsePuJetID = cms.bool(False),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    merge3rdJet = cms.bool(False),
    pujidWpPtBin1 = cms.vdouble(0.69, -0.35, -0.26, -0.21),
    pujidWpPtBin2 = cms.vdouble(0.86, -0.1, -0.05, -0.01),
    rmsforwardCut = cms.double(3.0),
    thirdJetDRCut = cms.double(1.8),
    vbfDNNpbfile = cms.FileInPath('flashgg/Taggers/data/vbfdnn_smAndCPodd_2021-08-31.pb'),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/data/STXSmodels/vbfDataDriven_IncUL2017.xml')
)


process.flashggVBFTag = cms.EDProducer("FlashggVBFTagProducer",
    Boundaries = cms.vdouble(0.553, 0.902, 0.957),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    DropNonGoldData = cms.bool(False),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    GetQCDWeights = cms.bool(False),
    GluGluHMVAResultTag = cms.InputTag("flashggGluGluHMVA"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0bin = cms.InputTag("rivetProducerHTXS","stage0bin"),
        stage1bin = cms.InputTag("rivetProducerHTXS","stage1bin")
    ),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireVBFPreselection = cms.bool(True),
    SetArbitraryNonGoldMC = cms.bool(False),
    SystLabel = cms.string(''),
    VBFDiPhoDiJetMVAResultTag = cms.InputTag("flashggVBFDiPhoDiJetMVA"),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA"),
    VBFPreselLeadPtMin = cms.double(40.0),
    VBFPreselPhoIDMVAMin = cms.double(-0.2),
    VBFPreselSubleadPtMin = cms.double(30.0),
    VHhadMVATag = cms.InputTag("flashggVHhadMVA")
)


process.flashggVHEtTag = cms.EDProducer("FlashggVHEtTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMets"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    dPhiDiphotonMetThreshold = cms.double(2.1),
    diphoMVAThreshold = cms.double(-1.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    metPtThreshold = cms.double(70),
    phoIdMVAThreshold = cms.double(-0.9),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useVertex0only = cms.bool(True)
)


process.flashggVHHadronicTag = cms.EDProducer("FlashggVHHadronicTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    cosThetaStarThreshold = cms.double(0.5),
    dRJetToPhoLThreshold = cms.double(0.4),
    dRJetToPhoSThreshold = cms.double(0.4),
    dijetMassHighThreshold = cms.double(120.0),
    dijetMassLowThreshold = cms.double(60.0),
    diphoMVAThreshold = cms.double(0.6),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(40.0),
    jetsNumberThreshold = cms.double(2.0),
    leadPhoOverMassThreshold = cms.double(0.5),
    phoIdMVAThreshold = cms.double(-0.9),
    subleadPhoOverMassThreshold = cms.double(0.25)
)


process.flashggVHLeptonicLooseTag = cms.EDProducer("FlashggVHLeptonicLooseTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.0),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetElectronThreshold = cms.double(0.4),
    deltaRJetMuonThreshold = cms.double(0.4),
    deltaRMuonPhoThreshold = cms.double(1),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.4),
    deltaRPhoSubLeadJet = cms.double(0.4),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    invMassLepHighThreshold = cms.double(110.0),
    invMassLepLowThreshold = cms.double(70.0),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(False)
)


process.flashggVHLooseTag = cms.EDProducer("FlashggVHLooseTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronPtThreshold = cms.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.187),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetMuonThreshold = cms.double(0.5),
    deltaRMuonPhoThreshold = cms.double(0.5),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.5),
    deltaRPhoSubLeadJet = cms.double(0.5),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(True)
)


process.flashggVHMetTag = cms.EDProducer("FlashggVHMetTagProducer",
    Boundaries = cms.vdouble(0.64612, 0.766, 0.85024),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    SystLabel = cms.string(''),
    VHMetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_VHMetTag_BDT_ULv1.weights.xml'),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    dPhiDiphotonMetThreshold = cms.double(0.0),
    deltaRJetPhoThreshold = cms.double(0.4),
    diphoMVAThreshold = cms.double(-1.0),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    leadPhoOverMassThreshold = cms.double(0.0),
    metPtThreshold = cms.double(0.0),
    phoIdMVAThreshold = cms.double(-1.0),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.0),
    vhmetanom_fa3zh_bdt_xmlfile = cms.FileInPath('flashgg/Taggers/data/VH_Anomalous/VHMet/VHMET_ZHiggs0MToGG_M125_withjet.xml')
)


process.flashggVHTightTag = cms.EDProducer("FlashggVHTightTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronPtThreshold = cms.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.187),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetElectronThreshold = cms.double(0.5),
    deltaRJetMuonThreshold = cms.double(0.5),
    deltaRLowPtMuonPhoThreshold = cms.double(0.5),
    deltaRMuonPhoThreshold = cms.double(1),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.5),
    deltaRPhoSubLeadJet = cms.double(0.5),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    invMassLepHighThreshold = cms.double(110.0),
    invMassLepLowThreshold = cms.double(70.0),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonLowPtThreshold = cms.double(10.0),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    numberOfHighPtMuonsThreshold = cms.double(1.0),
    numberOfLowPtMuonsThreshold = cms.double(2.0),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(True)
)


process.flashggVHhadMVA = cms.EDProducer("FlashggVHhadMVAProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    DrJetPhoton = cms.double(0.4),
    JetIDLevel = cms.string('Tight2017'),
    MVAMethod = cms.string('BDTG'),
    MinDijetMinv = cms.double(0.0),
    UseJetID = cms.bool(True),
    UsePuJetID = cms.bool(False),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    merge3rdJet = cms.bool(False),
    pujidWpPtBin1 = cms.vdouble(0.69, -0.35, -0.26, -0.21),
    pujidWpPtBin2 = cms.vdouble(0.86, -0.1, -0.05, -0.01),
    rmsforwardCut = cms.double(3.0),
    thirdJetDRCut = cms.double(1.8),
    vhHadMVAweightfile = cms.FileInPath('flashgg/Taggers/data/STXSmodels/vhHadDataDriven_IncUL2017.xml')
)


process.flashggWHLeptonicTag = cms.EDProducer("FlashggWHLeptonicTagProducer",
    Boundaries_0_75 = cms.vdouble(0.18438, 0.402),
    Boundaries_75_150 = cms.vdouble(0.27914, 0.482),
    Boundaries_GT150 = cms.vdouble(0.454),
    DeltaRTrkElec = cms.double(0.2),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMetSystematics"),
    METThreshold = cms.double(0.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(-1.0),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.4),
    SystLabel = cms.string(''),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    WHMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_WHLeptonicTag_BDT_ULv1.weights.xml'),
    deltaMassElectronZThreshold = cms.double(5.0),
    deltaRJetLepThreshold = cms.double(0.4),
    deltaRJetPhoThreshold = cms.double(0.4),
    deltaRMuonPhoThreshold = cms.double(0.2),
    deltaRPhoElectronThreshold = cms.double(0.2),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronPtThreshold = cms.double(15),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(999),
    leadPhoOverMassThreshold = cms.double(0.0),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    muonPtThreshold = cms.double(15),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.0)
)


process.flashggZHLeptonicTag = cms.EDProducer("FlashggZHLeptonicTagProducer",
    Boundaries = cms.vdouble(0.2307, 0.342),
    DeltaRTrkElec = cms.double(0.2),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(-1.0),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.9),
    SystLabel = cms.string(''),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    ZHMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_ZHLeptonicTag_BDT_ULv1.weights.xml'),
    deltaMassElectronZThreshold = cms.double(-1.0),
    deltaRJetLepThreshold = cms.double(0.4),
    deltaRJetPhoThreshold = cms.double(0.4),
    deltaRMuonPhoThreshold = cms.double(0.2),
    deltaRPhoElectronThreshold = cms.double(0.2),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronPtThreshold = cms.double(10),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    invMassLepHighThreshold = cms.double(120.0),
    invMassLepLowThreshold = cms.double(60.0),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20),
    leadPhoOverMassThreshold = cms.double(0.0),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    muonPtThreshold = cms.double(10),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.0)
)


process.flashggZPlusJetTag = cms.EDProducer("FlashggZPlusJetTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    )
)


process.flashggMetFilters = cms.EDFilter("flashggMetFilters",
    filtersInputTag = cms.InputTag("TriggerResults","","RECO"),
    requiredFilterNames = cms.untracked.vstring(
        'Flag_goodVertices', 
        'Flag_globalSuperTightHalo2016Filter', 
        'Flag_HBHENoiseFilter', 
        'Flag_HBHENoiseIsoFilter', 
        'Flag_EcalDeadCellTriggerPrimitiveFilter', 
        'Flag_BadPFMuonFilter', 
        'Flag_eeBadScFilter', 
        'Flag_ecalBadCalibFilter'
    )
)


process.flashggPreselectedDiPhotons = cms.EDFilter("GenericDiPhotonCandidateSelector",
    categories = cms.VPSet(
        cms.PSet(
            cut = cms.string('isEB && full5x5_r9>0.85'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('100000.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        ), 
        cms.PSet(
            cut = cms.string('isEE && full5x5_r9>0.90'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('100000.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    min = cms.string('0.8')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        ), 
        cms.PSet(
            cut = cms.string('isEB && full5x5_r9<=0.85'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('4.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('6.0')
                ), 
                cms.PSet(
                    max = cms.string('0.015')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        ), 
        cms.PSet(
            cut = cms.string('isEE && full5x5_r9<=0.90'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('4.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('6.0')
                ), 
                cms.PSet(
                    max = cms.string('0.035')
                ), 
                cms.PSet(
                    min = cms.string('0.8')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        )
    ),
    cut = cms.string('    (leadingPhoton.full5x5_r9>0.8||leadingPhoton.egChargedHadronIso<20||leadingPhoton.egChargedHadronIso/leadingPhoton.pt<0.3) && (subLeadingPhoton.full5x5_r9>0.8||subLeadingPhoton.egChargedHadronIso<20||subLeadingPhoton.egChargedHadronIso/subLeadingPhoton.pt<0.3) && (leadingPhoton.hadronicOverEm < 0.08 && subLeadingPhoton.hadronicOverEm < 0.08) && (leadingPhoton.pt >35.0 && subLeadingPhoton.pt > 25.0) && (abs(leadingPhoton.superCluster.eta) < 2.5 && abs(subLeadingPhoton.superCluster.eta) < 2.5) && (abs(leadingPhoton.superCluster.eta) < 1.4442 || abs(leadingPhoton.superCluster.eta) > 1.566) && (abs(subLeadingPhoton.superCluster.eta) < 1.4442 || abs(subLeadingPhoton.superCluster.eta) > 1.566) && (leadPhotonId > -0.9 && subLeadPhotonId > -0.9)'),
    rho = cms.InputTag("fixedGridRhoAll"),
    src = cms.InputTag("flashggPrefireDiPhotons"),
    variables = cms.vstring(
        'pfPhoIso03', 
        'trkSumPtHollowConeDR03', 
        'full5x5_sigmaIetaIeta', 
        'full5x5_r9', 
        'passElectronVeto'
    )
)


process.hltHighLevel = cms.EDFilter("HLTHighLevel",
    HLTPaths = cms.vstring(
        'HLT_Diphoton30_22_R9Id_OR_IsoCaloId_AND_HE_R9Id_Mass90*', 
        'HLT_Diphoton30_22_R9Id_OR_IsoCaloId_AND_HE_R9Id_Mass95*'
    ),
    TriggerResultsTag = cms.InputTag("TriggerResults","","HLT"),
    andOr = cms.bool(True),
    eventSetupPathsKey = cms.string(''),
    throw = cms.bool(True)
)


process.tagsDumper = cms.EDAnalyzer("StageOneDiPhotonTagDumper",
    categories = cms.VPSet(cms.PSet(
        className = cms.string('RECO_VH_MET_Tag0'),
        histograms = cms.VPSet(),
        label = cms.string(''),
        nAlphaSWeights = cms.int32(-1),
        nPdfWeights = cms.int32(-1),
        nScaleWeights = cms.int32(-1),
        splitPdfByStage0Bin = cms.bool(False),
        splitPdfByStage1Bin = cms.bool(True),
        subcats = cms.int32(0),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('tagTruth().HTXSstage1p2orderedBin'),
                name = cms.untracked.string('stage1p2bin'),
                nbins = cms.untracked.int32(57),
                vmax = cms.untracked.double(48.5),
                vmin = cms.untracked.double(-8.5)
            ), 
            cms.PSet(
                expr = cms.string('diPhoton().mass'),
                name = cms.untracked.string('CMS_hgg_mass'),
                nbins = cms.untracked.int32(160),
                vmax = cms.untracked.double(180.0),
                vmin = cms.untracked.double(100.0)
            ), 
            cms.PSet(
                expr = cms.string('(tagTruth().genPV().z-diPhoton().vtx().z)'),
                name = cms.untracked.string('dZ'),
                nbins = cms.untracked.int32(40),
                vmax = cms.untracked.double(20.0),
                vmin = cms.untracked.double(-20.0)
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().weight("NNLOPSweight")'),
                name = cms.untracked.string('NNLOPSweight'),
                nbins = cms.untracked.int32(1),
                vmax = cms.untracked.double(999999.0),
                vmin = cms.untracked.double(-999999.0)
            ), 
            cms.PSet(
                expr = cms.string('weight("btagReshapeNorm_TTH_LEP")'),
                name = cms.untracked.string('btagReshapeNorm_TTH_LEP'),
                nbins = cms.untracked.int32(1),
                vmax = cms.untracked.double(999999.0),
                vmin = cms.untracked.double(-999999.0)
            ), 
            cms.PSet(
                expr = cms.string('weight("btagReshapeNorm_TTH_HAD")'),
                name = cms.untracked.string('btagReshapeNorm_TTH_HAD'),
                nbins = cms.untracked.int32(1),
                vmax = cms.untracked.double(999999.0),
                vmin = cms.untracked.double(-999999.0)
            ), 
            cms.PSet(
                expr = cms.string('weight("btagReshapeNorm_THQ_LEP")'),
                name = cms.untracked.string('btagReshapeNorm_THQ_LEP'),
                nbins = cms.untracked.int32(1),
                vmax = cms.untracked.double(999999.0),
                vmin = cms.untracked.double(-999999.0)
            ), 
            cms.PSet(
                expr = cms.string('centralWeight'),
                name = cms.untracked.string('centralObjectWeight'),
                nbins = cms.untracked.int32(1),
                vmax = cms.untracked.double(999999.0),
                vmin = cms.untracked.double(-999999.0)
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.sumPt'),
                name = cms.untracked.string('dipho_sumpt')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.mass'),
                name = cms.untracked.string('dipho_mass')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.pt'),
                name = cms.untracked.string('dipho_leadPt')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.eta'),
                name = cms.untracked.string('dipho_leadEta')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.phi'),
                name = cms.untracked.string('dipho_leadPhi')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.energy'),
                name = cms.untracked.string('dipho_leadE')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.sigmaIetaIeta'),
                name = cms.untracked.string('dipho_lead_sieie')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.hadronicOverEm'),
                name = cms.untracked.string('dipho_lead_hoe')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.sigEOverE'),
                name = cms.untracked.string('dipho_lead_sigmaEoE')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.pt/diPhoton.mass'),
                name = cms.untracked.string('dipho_lead_ptoM')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.full5x5_r9'),
                name = cms.untracked.string('dipho_leadR9')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingView.phoIdMvaWrtChosenVtx'),
                name = cms.untracked.string('dipho_leadIDMVA')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.passElectronVeto'),
                name = cms.untracked.string('dipho_lead_elveto')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.hasPixelSeed'),
                name = cms.untracked.string('dipho_leadhasPixelSeed')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.genMatchType'),
                name = cms.untracked.string('dipho_lead_prompt')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.pt'),
                name = cms.untracked.string('dipho_subleadPt')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.eta'),
                name = cms.untracked.string('dipho_subleadEta')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.phi'),
                name = cms.untracked.string('dipho_subleadPhi')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.energy'),
                name = cms.untracked.string('dipho_subleadE')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.sigmaIetaIeta'),
                name = cms.untracked.string('dipho_sublead_sieie')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.hadronicOverEm'),
                name = cms.untracked.string('dipho_sublead_hoe')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.sigEOverE'),
                name = cms.untracked.string('dipho_sublead_sigmaEoE')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.pt/diPhoton.mass'),
                name = cms.untracked.string('dipho_sublead_ptoM')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.full5x5_r9'),
                name = cms.untracked.string('dipho_subleadR9')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingView.phoIdMvaWrtChosenVtx'),
                name = cms.untracked.string('dipho_subleadIDMVA')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.passElectronVeto'),
                name = cms.untracked.string('dipho_sublead_elveto')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.hasPixelSeed'),
                name = cms.untracked.string('dipho_subleadhasPixelSeed')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.genMatchType'),
                name = cms.untracked.string('dipho_sublead_prompt')
            ), 
            cms.PSet(
                expr = cms.string('diPhotonMVA.result'),
                name = cms.untracked.string('dipho_mva')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.pt/diPhoton.mass'),
                name = cms.untracked.string('dipho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('diPhotonMVA.sigmarv'),
                name = cms.untracked.string('sigmarv')
            ), 
            cms.PSet(
                expr = cms.string('diPhotonMVA.decorrSigmarv'),
                name = cms.untracked.string('sigmarvDecorr')
            ), 
            cms.PSet(
                expr = cms.string('diPhotonMVA.sigmawv'),
                name = cms.untracked.string('sigmawv')
            ), 
            cms.PSet(
                expr = cms.string('diPhotonMVA.CosPhi'),
                name = cms.untracked.string('CosPhi')
            ), 
            cms.PSet(
                expr = cms.string('diPhotonMVA.vtxprob'),
                name = cms.untracked.string('vtxprob')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.pt'),
                name = cms.untracked.string('pt')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.superCluster.eta'),
                name = cms.untracked.string('leadSCeta')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.superCluster.eta'),
                name = cms.untracked.string('subleadSCeta')
            ), 
            cms.PSet(
                expr = cms.string('jets.size'),
                name = cms.untracked.string('n_jets')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>0)? jets.at(0).pt      : -999'),
                name = cms.untracked.string('jet1_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>0)? jets.at(0).eta     : -999'),
                name = cms.untracked.string('jet1_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>0)? jets.at(0).phi     : -999'),
                name = cms.untracked.string('jet1_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>0)? jets.at(0).energy  : -999'),
                name = cms.untracked.string('jet1_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>0)? jets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet1_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>1)? jets.at(1).pt      : -999'),
                name = cms.untracked.string('jet2_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>1)? jets.at(1).eta     : -999'),
                name = cms.untracked.string('jet2_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>1)? jets.at(1).phi     : -999'),
                name = cms.untracked.string('jet2_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>1)? jets.at(1).energy  : -999'),
                name = cms.untracked.string('jet2_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>1)? jets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet2_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>2)? jets.at(2).pt      : -999'),
                name = cms.untracked.string('jet3_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>2)? jets.at(2).eta     : -999'),
                name = cms.untracked.string('jet3_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>2)? jets.at(2).phi     : -999'),
                name = cms.untracked.string('jet3_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>2)? jets.at(2).energy  : -999'),
                name = cms.untracked.string('jet3_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>2)? jets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet3_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>3)? jets.at(3).pt      : -999'),
                name = cms.untracked.string('jet4_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>3)? jets.at(3).eta     : -999'),
                name = cms.untracked.string('jet4_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>3)? jets.at(3).phi     : -999'),
                name = cms.untracked.string('jet4_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>3)? jets.at(3).energy  : -999'),
                name = cms.untracked.string('jet4_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>3)? jets.at(3).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(3).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet4_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>4)? jets.at(4).pt      : -999'),
                name = cms.untracked.string('jet5_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>4)? jets.at(4).eta     : -999'),
                name = cms.untracked.string('jet5_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>4)? jets.at(4).phi     : -999'),
                name = cms.untracked.string('jet5_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>4)? jets.at(4).energy  : -999'),
                name = cms.untracked.string('jet5_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>4)? jets.at(4).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(4).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet5_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>5)? jets.at(5).pt      : -999'),
                name = cms.untracked.string('jet6_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>5)? jets.at(5).eta     : -999'),
                name = cms.untracked.string('jet6_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>5)? jets.at(5).phi     : -999'),
                name = cms.untracked.string('jet6_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>5)? jets.at(5).energy  : -999'),
                name = cms.untracked.string('jet6_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>5)? jets.at(5).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(5).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet6_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>6)? jets.at(6).pt      : -999'),
                name = cms.untracked.string('jet7_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>6)? jets.at(6).eta     : -999'),
                name = cms.untracked.string('jet7_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>6)? jets.at(6).phi     : -999'),
                name = cms.untracked.string('jet7_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>6)? jets.at(6).energy  : -999'),
                name = cms.untracked.string('jet7_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>6)? jets.at(6).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(6).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet7_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>7)? jets.at(7).pt      : -999'),
                name = cms.untracked.string('jet8_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>7)? jets.at(7).eta     : -999'),
                name = cms.untracked.string('jet8_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>7)? jets.at(7).phi     : -999'),
                name = cms.untracked.string('jet8_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>7)? jets.at(7).energy  : -999'),
                name = cms.untracked.string('jet8_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>7)? jets.at(7).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(7).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet8_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>8)? jets.at(8).pt      : -999'),
                name = cms.untracked.string('jet9_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>8)? jets.at(8).eta     : -999'),
                name = cms.untracked.string('jet9_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>8)? jets.at(8).phi     : -999'),
                name = cms.untracked.string('jet9_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>8)? jets.at(8).energy  : -999'),
                name = cms.untracked.string('jet9_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>8)? jets.at(8).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(8).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet9_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>9)? jets.at(9).pt      : -999'),
                name = cms.untracked.string('jet10_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>9)? jets.at(9).eta     : -999'),
                name = cms.untracked.string('jet10_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>9)? jets.at(9).phi     : -999'),
                name = cms.untracked.string('jet10_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>9)? jets.at(9).energy  : -999'),
                name = cms.untracked.string('jet10_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>9)? jets.at(9).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(9).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet10_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>10)? jets.at(10).pt      : -999'),
                name = cms.untracked.string('jet11_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>10)? jets.at(10).eta     : -999'),
                name = cms.untracked.string('jet11_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>10)? jets.at(10).phi     : -999'),
                name = cms.untracked.string('jet11_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>10)? jets.at(10).energy  : -999'),
                name = cms.untracked.string('jet11_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>10)? jets.at(10).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(10).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet11_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>11)? jets.at(11).pt      : -999'),
                name = cms.untracked.string('jet12_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>11)? jets.at(11).eta     : -999'),
                name = cms.untracked.string('jet12_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>11)? jets.at(11).phi     : -999'),
                name = cms.untracked.string('jet12_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>11)? jets.at(11).energy  : -999'),
                name = cms.untracked.string('jet12_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>11)? jets.at(11).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(11).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet12_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>12)? jets.at(12).pt      : -999'),
                name = cms.untracked.string('jet13_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>12)? jets.at(12).eta     : -999'),
                name = cms.untracked.string('jet13_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>12)? jets.at(12).phi     : -999'),
                name = cms.untracked.string('jet13_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>12)? jets.at(12).energy  : -999'),
                name = cms.untracked.string('jet13_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>12)? jets.at(12).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(12).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet13_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>13)? jets.at(13).pt      : -999'),
                name = cms.untracked.string('jet14_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>13)? jets.at(13).eta     : -999'),
                name = cms.untracked.string('jet14_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>13)? jets.at(13).phi     : -999'),
                name = cms.untracked.string('jet14_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>13)? jets.at(13).energy  : -999'),
                name = cms.untracked.string('jet14_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>13)? jets.at(13).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(13).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet14_deepbtag')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>14)? jets.at(14).pt      : -999'),
                name = cms.untracked.string('jet15_Pt')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>14)? jets.at(14).eta     : -999'),
                name = cms.untracked.string('jet15_Eta')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>14)? jets.at(14).phi     : -999'),
                name = cms.untracked.string('jet15_Phi')
            ), 
            cms.PSet(
                expr = cms.string('?(jets.size>14)? jets.at(14).energy  : -999'),
                name = cms.untracked.string('jet15_E')
            ), 
            cms.PSet(
                expr = cms.string("?(jets.size>14)? jets.at(14).bDiscriminator(\'pfDeepCSVJetTags:probb\') + jets.at(14).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -999"),
                name = cms.untracked.string('jet15_deepbtag')
            )
        )
    )),
    className = cms.untracked.string('StageOneDiPhotonTagDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet(cms.PSet(
            cut = cms.string('hasSyst("") '),
            name = cms.untracked.string('')
        )),
        remap = cms.untracked.VPSet(cms.untracked.PSet(
            dst = cms.untracked.string('RECO_VH_MET_Tag0'),
            src = cms.untracked.string('flashggRECO_VH_MET_Tag0')
        ))
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(False),
    dumpTrees = cms.untracked.bool(True),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(),
        dumpLHEInfo = cms.bool(False),
        extraFloats = cms.PSet(

        ),
        lhePartTable = cms.InputTag("lheInfoTable","LHEPart"),
        lheTable = cms.InputTag("lheInfoTable","LHE"),
        mcPu = cms.vdouble(),
        puBins = cms.vdouble(),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(False),
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    intLumi = cms.untracked.double(0),
    lumiWeight = cms.double(1.0),
    maxCandPerEvent = cms.int32(-1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$CLASSNAME_$SUBCAT_$LABEL'),
    processId = cms.string('Data'),
    processIndex = cms.int32(0),
    quietRooFit = cms.untracked.bool(True),
    splitPdfByStage0Bin = cms.untracked.bool(False),
    splitPdfByStage1Bin = cms.untracked.bool(True),
    src = cms.InputTag("flashggSystTagMerger"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)


process.MessageLogger = cms.Service("MessageLogger",
    FrameworkJobReport = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        optionalPSet = cms.untracked.bool(True)
    ),
    categories = cms.untracked.vstring(
        'FwkJob', 
        'FwkReport', 
        'FwkSummary', 
        'Root_NoDictionary'
    ),
    cerr = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        FwkReport = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1000)
        ),
        FwkSummary = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1)
        ),
        INFO = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000)
        ),
        noTimeStamps = cms.untracked.bool(False),
        optionalPSet = cms.untracked.bool(True),
        threshold = cms.untracked.string('INFO')
    ),
    cerr_stats = cms.untracked.PSet(
        optionalPSet = cms.untracked.bool(True),
        output = cms.untracked.string('cerr'),
        threshold = cms.untracked.string('WARNING')
    ),
    cout = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    debugModules = cms.untracked.vstring(),
    debugs = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    default = cms.untracked.PSet(

    ),
    destinations = cms.untracked.vstring(
        'warnings', 
        'errors', 
        'infos', 
        'debugs', 
        'cout', 
        'cerr'
    ),
    errors = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    fwkJobReports = cms.untracked.vstring('FrameworkJobReport'),
    infos = cms.untracked.PSet(
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        optionalPSet = cms.untracked.bool(True),
        placeholder = cms.untracked.bool(True)
    ),
    statistics = cms.untracked.vstring('cerr_stats'),
    suppressDebug = cms.untracked.vstring(),
    suppressInfo = cms.untracked.vstring(),
    suppressWarning = cms.untracked.vstring(),
    warnings = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    )
)


process.RandomNumberGeneratorService = cms.Service("RandomNumberGeneratorService",
    flashggDifferentialPhoIdInputsCorrection = cms.PSet(
        initialSeed = cms.untracked.uint32(90)
    )
)


process.TFileService = cms.Service("TFileService",
    fileName = cms.string('/eos/user/x/xisu/WorkSpace/VH_AC_Analysis/flashgg_output/UL_dataset/UL_17/UL_17_data/output_DoubleEG_alesauva-UL_test-10_6_4-v0-Run2017B-09Aug2019_UL2017-v1-53faf905fdb551f89c40f719673e864f_USER_numEvent10000.root')
)


process.CSCGeometryESModule = cms.ESProducer("CSCGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    debugV = cms.untracked.bool(False),
    useCentreTIOffsets = cms.bool(False),
    useDDD = cms.bool(False),
    useGangedStripsInME1a = cms.bool(True),
    useOnlyWiresInME1a = cms.bool(False),
    useRealWireGeometry = cms.bool(True)
)


process.CaloGeometryBuilder = cms.ESProducer("CaloGeometryBuilder",
    SelectedCalos = cms.vstring(
        'HCAL', 
        'ZDC', 
        'CASTOR', 
        'EcalBarrel', 
        'EcalEndcap', 
        'EcalPreshower', 
        'TOWER'
    )
)


process.CaloTopologyBuilder = cms.ESProducer("CaloTopologyBuilder")


process.CaloTowerGeometryFromDBEP = cms.ESProducer("CaloTowerGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.CaloTowerTopologyEP = cms.ESProducer("CaloTowerTopologyEP")


process.CastorDbProducer = cms.ESProducer("CastorDbProducer",
    appendToDataLabel = cms.string('')
)


process.CastorGeometryFromDBEP = cms.ESProducer("CastorGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.DTGeometryESModule = cms.ESProducer("DTGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    fromDDD = cms.bool(False)
)


process.EcalBarrelGeometryFromDBEP = cms.ESProducer("EcalBarrelGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalElectronicsMappingBuilder = cms.ESProducer("EcalElectronicsMappingBuilder")


process.EcalEndcapGeometryFromDBEP = cms.ESProducer("EcalEndcapGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalLaserCorrectionService = cms.ESProducer("EcalLaserCorrectionService")


process.EcalPreshowerGeometryFromDBEP = cms.ESProducer("EcalPreshowerGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalTrigTowerConstituentsMapBuilder = cms.ESProducer("EcalTrigTowerConstituentsMapBuilder",
    MapFile = cms.untracked.string('Geometry/EcalMapping/data/EndCap_TTMap.txt')
)


process.GlobalTrackingGeometryESProducer = cms.ESProducer("GlobalTrackingGeometryESProducer")


process.HcalAlignmentEP = cms.ESProducer("HcalAlignmentEP")


process.HcalGeometryFromDBEP = cms.ESProducer("HcalGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.JetResolutionESProducer_AK4PFchs = cms.ESProducer("JetResolutionESProducer",
    label = cms.string('AK4PFchs')
)


process.JetResolutionESProducer_SF_AK4PFchs = cms.ESProducer("JetResolutionScaleFactorESProducer",
    label = cms.string('AK4PFchs')
)


process.MuonDetLayerGeometryESProducer = cms.ESProducer("MuonDetLayerGeometryESProducer")


process.MuonNumberingInitialization = cms.ESProducer("MuonNumberingInitialization")


process.ParabolicParametrizedMagneticFieldProducer = cms.ESProducer("AutoParametrizedMagneticFieldProducer",
    label = cms.untracked.string('ParabolicMf'),
    valueOverride = cms.int32(-1),
    version = cms.string('Parabolic')
)


process.RPCGeometryESModule = cms.ESProducer("RPCGeometryESModule",
    compatibiltyWith11 = cms.untracked.bool(True),
    useDDD = cms.untracked.bool(False)
)


process.SiStripRecHitMatcherESProducer = cms.ESProducer("SiStripRecHitMatcherESProducer",
    ComponentName = cms.string('StandardMatcher'),
    NSigmaInside = cms.double(3.0),
    PreFilter = cms.bool(False)
)


process.StripCPEfromTrackAngleESProducer = cms.ESProducer("StripCPEESProducer",
    ComponentName = cms.string('StripCPEfromTrackAngle'),
    ComponentType = cms.string('StripCPEfromTrackAngle'),
    parameters = cms.PSet(
        mLC_P0 = cms.double(-0.326),
        mLC_P1 = cms.double(0.618),
        mLC_P2 = cms.double(0.3),
        mTEC_P0 = cms.double(-1.885),
        mTEC_P1 = cms.double(0.471),
        mTIB_P0 = cms.double(-0.742),
        mTIB_P1 = cms.double(0.202),
        mTID_P0 = cms.double(-1.427),
        mTID_P1 = cms.double(0.433),
        mTOB_P0 = cms.double(-1.026),
        mTOB_P1 = cms.double(0.253),
        maxChgOneMIP = cms.double(6000.0),
        useLegacyError = cms.bool(False)
    )
)


process.TrackerRecoGeometryESProducer = cms.ESProducer("TrackerRecoGeometryESProducer")


process.VolumeBasedMagneticFieldESProducer = cms.ESProducer("VolumeBasedMagneticFieldESProducerFromDB",
    debugBuilder = cms.untracked.bool(False),
    label = cms.untracked.string(''),
    valueOverride = cms.int32(-1)
)


process.XMLFromDBSource = cms.ESProducer("XMLIdealGeometryESProducer",
    label = cms.string('Extended'),
    rootDDName = cms.string('cms:OCMS')
)


process.ZdcGeometryFromDBEP = cms.ESProducer("ZdcGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.ak4CaloL1FastL2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4CaloL1Fastjet', 
        'ak4CaloL2Relative', 
        'ak4CaloL3Absolute'
    )
)


process.ak4CaloL1FastL2L3L6 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4CaloL1Fastjet', 
        'ak4CaloL2Relative', 
        'ak4CaloL3Absolute', 
        'ak4CaloL6SLB'
    )
)


process.ak4CaloL1FastL2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4CaloL1Fastjet', 
        'ak4CaloL2Relative', 
        'ak4CaloL3Absolute', 
        'ak4CaloResidual'
    )
)


process.ak4CaloL1Fastjet = cms.ESProducer("L1FastjetCorrectionESProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAllCalo")
)


process.ak4CaloL1L2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4CaloL1Offset', 
        'ak4CaloL2Relative', 
        'ak4CaloL3Absolute'
    )
)


process.ak4CaloL1L2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4CaloL1Offset', 
        'ak4CaloL2Relative', 
        'ak4CaloL3Absolute', 
        'ak4CaloResidual'
    )
)


process.ak4CaloL1Offset = cms.ESProducer("L1OffsetCorrectionESProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.string('offlinePrimaryVertices')
)


process.ak4CaloL2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4CaloL2Relative', 
        'ak4CaloL3Absolute'
    )
)


process.ak4CaloL2L3L6 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4CaloL2Relative', 
        'ak4CaloL3Absolute', 
        'ak4CaloL6SLB'
    )
)


process.ak4CaloL2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4CaloL2Relative', 
        'ak4CaloL3Absolute', 
        'ak4CaloResidual'
    )
)


process.ak4CaloL2Relative = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L2Relative')
)


process.ak4CaloL3Absolute = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L3Absolute')
)


process.ak4CaloL6SLB = cms.ESProducer("L6SLBCorrectionESProducer",
    addMuonToJet = cms.bool(True),
    algorithm = cms.string(''),
    level = cms.string('L6SLB'),
    srcBTagInfoElectron = cms.InputTag("ak4CaloJetsSoftElectronTagInfos"),
    srcBTagInfoMuon = cms.InputTag("ak4CaloJetsSoftMuonTagInfos")
)


process.ak4CaloResidual = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L2L3Residual')
)


process.ak4JPTL1FastL2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4L1JPTFastjet', 
        'ak4JPTL2Relative', 
        'ak4JPTL3Absolute'
    )
)


process.ak4JPTL1FastL2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4L1JPTFastjet', 
        'ak4JPTL2Relative', 
        'ak4JPTL3Absolute', 
        'ak4JPTResidual'
    )
)


process.ak4JPTL1L2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4L1JPTOffset', 
        'ak4JPTL2Relative', 
        'ak4JPTL3Absolute'
    )
)


process.ak4JPTL1L2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4L1JPTOffset', 
        'ak4JPTL2Relative', 
        'ak4JPTL3Absolute', 
        'ak4JPTResidual'
    )
)


process.ak4JPTL1Offset = cms.ESProducer("L1OffsetCorrectionESProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.string('offlinePrimaryVertices')
)


process.ak4JPTL2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4L1JPTOffset', 
        'ak4JPTL2Relative', 
        'ak4JPTL3Absolute'
    )
)


process.ak4JPTL2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4L1JPTOffset', 
        'ak4JPTL2Relative', 
        'ak4JPTL3Absolute', 
        'ak4JPTResidual'
    )
)


process.ak4JPTL2Relative = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L2Relative')
)


process.ak4JPTL3Absolute = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L3Absolute')
)


process.ak4JPTResidual = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L2L3Residual')
)


process.ak4L1JPTFastjet = cms.ESProducer("L1JPTOffsetCorrectionESProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L1JPTOffset'),
    offsetService = cms.string('ak4CaloL1Fastjet')
)


process.ak4L1JPTOffset = cms.ESProducer("L1JPTOffsetCorrectionESProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L1JPTOffset'),
    offsetService = cms.string('ak4CaloL1Offset')
)


process.ak4PFCHSL1FastL2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFCHSL1Fastjet', 
        'ak4PFCHSL2Relative', 
        'ak4PFCHSL3Absolute'
    )
)


process.ak4PFCHSL1FastL2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFCHSL1Fastjet', 
        'ak4PFCHSL2Relative', 
        'ak4PFCHSL3Absolute', 
        'ak4PFCHSResidual'
    )
)


process.ak4PFCHSL1Fastjet = cms.ESProducer("L1FastjetCorrectionESProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFCHSL1L2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFCHSL1Offset', 
        'ak4PFCHSL2Relative', 
        'ak4PFCHSL3Absolute'
    )
)


process.ak4PFCHSL1L2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFCHSL1Offset', 
        'ak4PFCHSL2Relative', 
        'ak4PFCHSL3Absolute', 
        'ak4PFCHSResidual'
    )
)


process.ak4PFCHSL1Offset = cms.ESProducer("L1OffsetCorrectionESProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.string('offlinePrimaryVertices')
)


process.ak4PFCHSL2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFCHSL2Relative', 
        'ak4PFCHSL3Absolute'
    )
)


process.ak4PFCHSL2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFCHSL2Relative', 
        'ak4PFCHSL3Absolute', 
        'ak4PFCHSResidual'
    )
)


process.ak4PFCHSL2Relative = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L2Relative')
)


process.ak4PFCHSL3Absolute = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L3Absolute')
)


process.ak4PFCHSResidual = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L2L3Residual')
)


process.ak4PFL1FastL2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFL1Fastjet', 
        'ak4PFL2Relative', 
        'ak4PFL3Absolute'
    )
)


process.ak4PFL1FastL2L3L6 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFL1Fastjet', 
        'ak4PFL2Relative', 
        'ak4PFL3Absolute', 
        'ak4PFL6SLB'
    )
)


process.ak4PFL1FastL2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFL1Fastjet', 
        'ak4PFL2Relative', 
        'ak4PFL3Absolute', 
        'ak4PFResidual'
    )
)


process.ak4PFL1Fastjet = cms.ESProducer("L1FastjetCorrectionESProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFL1L2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFL1Offset', 
        'ak4PFL2Relative', 
        'ak4PFL3Absolute'
    )
)


process.ak4PFL1L2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFL1Offset', 
        'ak4PFL2Relative', 
        'ak4PFL3Absolute', 
        'ak4PFResidual'
    )
)


process.ak4PFL1Offset = cms.ESProducer("L1OffsetCorrectionESProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.string('offlinePrimaryVertices')
)


process.ak4PFL2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFL2Relative', 
        'ak4PFL3Absolute'
    )
)


process.ak4PFL2L3L6 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFL2Relative', 
        'ak4PFL3Absolute', 
        'ak4PFL6SLB'
    )
)


process.ak4PFL2L3Residual = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4PFL2Relative', 
        'ak4PFL3Absolute', 
        'ak4PFResidual'
    )
)


process.ak4PFL2Relative = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L2Relative')
)


process.ak4PFL3Absolute = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L3Absolute')
)


process.ak4PFL6SLB = cms.ESProducer("L6SLBCorrectionESProducer",
    addMuonToJet = cms.bool(False),
    algorithm = cms.string(''),
    level = cms.string('L6SLB'),
    srcBTagInfoElectron = cms.InputTag("ak4PFJetsSoftElectronTagInfos"),
    srcBTagInfoMuon = cms.InputTag("ak4PFJetsSoftMuonTagInfos")
)


process.ak4PFResidual = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L2L3Residual')
)


process.ak4TrackL2L3 = cms.ESProducer("JetCorrectionESChain",
    correctors = cms.vstring(
        'ak4TrackL2Relative', 
        'ak4TrackL3Absolute'
    )
)


process.ak4TrackL2Relative = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK5TRK'),
    level = cms.string('L2Relative')
)


process.ak4TrackL3Absolute = cms.ESProducer("LXXXCorrectionESProducer",
    algorithm = cms.string('AK5TRK'),
    level = cms.string('L3Absolute')
)


process.fakeForIdealAlignment = cms.ESProducer("FakeAlignmentProducer",
    appendToDataLabel = cms.string('fakeForIdeal')
)


process.hcalDDDRecConstants = cms.ESProducer("HcalDDDRecConstantsESModule",
    appendToDataLabel = cms.string('')
)


process.hcalDDDSimConstants = cms.ESProducer("HcalDDDSimConstantsESModule",
    appendToDataLabel = cms.string('')
)


process.hcalTopologyIdeal = cms.ESProducer("HcalTopologyIdealEP",
    Exclude = cms.untracked.string(''),
    MergePosition = cms.untracked.bool(False),
    appendToDataLabel = cms.string('')
)


process.hcal_db_producer = cms.ESProducer("HcalDbProducer",
    dump = cms.untracked.vstring(''),
    file = cms.untracked.string('')
)


process.idealForDigiCSCGeometry = cms.ESProducer("CSCGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    debugV = cms.untracked.bool(False),
    useCentreTIOffsets = cms.bool(False),
    useDDD = cms.bool(False),
    useGangedStripsInME1a = cms.bool(True),
    useOnlyWiresInME1a = cms.bool(False),
    useRealWireGeometry = cms.bool(True)
)


process.idealForDigiDTGeometry = cms.ESProducer("DTGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    fromDDD = cms.bool(False)
)


process.idealForDigiTrackerGeometry = cms.ESProducer("TrackerDigiGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    fromDDD = cms.bool(False)
)


process.siPixelQualityESProducer = cms.ESProducer("SiPixelQualityESProducer",
    ListOfRecordToMerge = cms.VPSet(
        cms.PSet(
            record = cms.string('SiPixelQualityFromDbRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiPixelDetVOffRcd'),
            tag = cms.string('')
        )
    ),
    siPixelQualityLabel = cms.string('')
)


process.siStripBackPlaneCorrectionDepESProducer = cms.ESProducer("SiStripBackPlaneCorrectionDepESProducer",
    BackPlaneCorrectionDeconvMode = cms.PSet(
        label = cms.untracked.string('deconvolution'),
        record = cms.string('SiStripBackPlaneCorrectionRcd')
    ),
    BackPlaneCorrectionPeakMode = cms.PSet(
        label = cms.untracked.string('peak'),
        record = cms.string('SiStripBackPlaneCorrectionRcd')
    ),
    LatencyRecord = cms.PSet(
        label = cms.untracked.string(''),
        record = cms.string('SiStripLatencyRcd')
    )
)


process.siStripGainESProducer = cms.ESProducer("SiStripGainESProducer",
    APVGain = cms.VPSet(
        cms.PSet(
            Label = cms.untracked.string(''),
            NormalizationFactor = cms.untracked.double(1.0),
            Record = cms.string('SiStripApvGainRcd')
        ), 
        cms.PSet(
            Label = cms.untracked.string(''),
            NormalizationFactor = cms.untracked.double(1.0),
            Record = cms.string('SiStripApvGain2Rcd')
        )
    ),
    AutomaticNormalization = cms.bool(False),
    appendToDataLabel = cms.string(''),
    printDebug = cms.untracked.bool(False)
)


process.siStripLorentzAngleDepESProducer = cms.ESProducer("SiStripLorentzAngleDepESProducer",
    LatencyRecord = cms.PSet(
        label = cms.untracked.string(''),
        record = cms.string('SiStripLatencyRcd')
    ),
    LorentzAngleDeconvMode = cms.PSet(
        label = cms.untracked.string('deconvolution'),
        record = cms.string('SiStripLorentzAngleRcd')
    ),
    LorentzAnglePeakMode = cms.PSet(
        label = cms.untracked.string('peak'),
        record = cms.string('SiStripLorentzAngleRcd')
    )
)


process.siStripQualityESProducer = cms.ESProducer("SiStripQualityESProducer",
    ListOfRecordToMerge = cms.VPSet(
        cms.PSet(
            record = cms.string('SiStripDetVOffRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripDetCablingRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('RunInfoRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadChannelRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadFiberRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadModuleRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadStripRcd'),
            tag = cms.string('')
        )
    ),
    PrintDebugOutput = cms.bool(False),
    ReduceGranularity = cms.bool(False),
    ThresholdForReducedGranularity = cms.double(0.3),
    UseEmptyRunInfo = cms.bool(False),
    appendToDataLabel = cms.string('')
)


process.sistripconn = cms.ESProducer("SiStripConnectivity")


process.stripCPEESProducer = cms.ESProducer("StripCPEESProducer",
    ComponentName = cms.string('stripCPE'),
    ComponentType = cms.string('SimpleStripCPE'),
    parameters = cms.PSet(

    )
)


process.trackerGeometryDB = cms.ESProducer("TrackerDigiGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    fromDDD = cms.bool(False)
)


process.trackerNumberingGeometryDB = cms.ESProducer("TrackerGeometricDetESModule",
    appendToDataLabel = cms.string(''),
    fromDDD = cms.bool(False)
)


process.trackerTopology = cms.ESProducer("TrackerTopologyEP",
    appendToDataLabel = cms.string('')
)


process.GlobalTag = cms.ESSource("PoolDBESSource",
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        messageLevel = cms.untracked.int32(0),
        security = cms.untracked.string('')
    ),
    DumpStat = cms.untracked.bool(False),
    ReconnectEachRun = cms.untracked.bool(False),
    RefreshAlways = cms.untracked.bool(False),
    RefreshEachRun = cms.untracked.bool(False),
    RefreshOpenIOVs = cms.untracked.bool(False),
    connect = cms.string('frontier://FrontierProd/CMS_CONDITIONS'),
    globaltag = cms.string('106X_dataRun2_v35'),
    pfnPostfix = cms.untracked.string(''),
    pfnPrefix = cms.untracked.string(''),
    snapshotTime = cms.string(''),
    toGet = cms.VPSet()
)


process.HcalTimeSlewEP = cms.ESSource("HcalTimeSlewEP",
    appendToDataLabel = cms.string('HBHE'),
    timeSlewParametersM2 = cms.VPSet(
        cms.PSet(
            slope = cms.double(-3.178648),
            tmax = cms.double(16.0),
            tzero = cms.double(23.960177)
        ), 
        cms.PSet(
            slope = cms.double(-1.5610227),
            tmax = cms.double(10.0),
            tzero = cms.double(11.977461)
        ), 
        cms.PSet(
            slope = cms.double(-1.075824),
            tmax = cms.double(6.25),
            tzero = cms.double(9.109694)
        )
    ),
    timeSlewParametersM3 = cms.VPSet(
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(12.2999),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-2.19142),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(0.0),
            tspar2_siPM = cms.double(0.0)
        ), 
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(15.5),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-3.2),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(32.0),
            tspar2_siPM = cms.double(0.0)
        ), 
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(12.2999),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-2.19142),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(0.0),
            tspar2_siPM = cms.double(0.0)
        ), 
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(12.2999),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-2.19142),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(0.0),
            tspar2_siPM = cms.double(0.0)
        )
    )
)


process.eegeom = cms.ESSource("EmptyESSource",
    firstValid = cms.vuint32(1),
    iovIsRunNotTime = cms.bool(True),
    recordName = cms.string('EcalMappingRcd')
)


process.es_hardcode = cms.ESSource("HcalHardcodeCalibrations",
    GainWidthsForTrigPrims = cms.bool(False),
    HBRecalibration = cms.bool(False),
    HBmeanenergies = cms.FileInPath('CalibCalorimetry/HcalPlugins/data/meanenergiesHB.txt'),
    HBreCalibCutoff = cms.double(20.0),
    HERecalibration = cms.bool(False),
    HEmeanenergies = cms.FileInPath('CalibCalorimetry/HcalPlugins/data/meanenergiesHE.txt'),
    HEreCalibCutoff = cms.double(20.0),
    HFRecalParameterBlock = cms.PSet(
        HFdepthOneParameterA = cms.vdouble(
            0.004123, 0.00602, 0.008201, 0.010489, 0.013379, 
            0.016997, 0.021464, 0.027371, 0.034195, 0.044807, 
            0.058939, 0.125497
        ),
        HFdepthOneParameterB = cms.vdouble(
            -4e-06, -2e-06, 0.0, 4e-06, 1.5e-05, 
            2.6e-05, 6.3e-05, 8.4e-05, 0.00016, 0.000107, 
            0.000425, 0.000209
        ),
        HFdepthTwoParameterA = cms.vdouble(
            0.002861, 0.004168, 0.0064, 0.008388, 0.011601, 
            0.014425, 0.018633, 0.023232, 0.028274, 0.035447, 
            0.051579, 0.086593
        ),
        HFdepthTwoParameterB = cms.vdouble(
            -2e-06, -0.0, -7e-06, -6e-06, -2e-06, 
            1e-06, 1.9e-05, 3.1e-05, 6.7e-05, 1.2e-05, 
            0.000157, -3e-06
        )
    ),
    HFRecalibration = cms.bool(False),
    SiPMCharacteristics = cms.VPSet(
        cms.PSet(
            crosstalk = cms.double(0.0),
            nonlin1 = cms.double(1.0),
            nonlin2 = cms.double(0.0),
            nonlin3 = cms.double(0.0),
            pixels = cms.int32(36000)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.0),
            nonlin1 = cms.double(1.0),
            nonlin2 = cms.double(0.0),
            nonlin3 = cms.double(0.0),
            pixels = cms.int32(2500)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.17),
            nonlin1 = cms.double(1.00985),
            nonlin2 = cms.double(7.84089e-06),
            nonlin3 = cms.double(2.86282e-10),
            pixels = cms.int32(27370)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.196),
            nonlin1 = cms.double(1.00546),
            nonlin2 = cms.double(6.40239e-06),
            nonlin3 = cms.double(1.27011e-10),
            pixels = cms.int32(38018)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.17),
            nonlin1 = cms.double(1.00985),
            nonlin2 = cms.double(7.84089e-06),
            nonlin3 = cms.double(2.86282e-10),
            pixels = cms.int32(27370)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.196),
            nonlin1 = cms.double(1.00546),
            nonlin2 = cms.double(6.40239e-06),
            nonlin3 = cms.double(1.27011e-10),
            pixels = cms.int32(38018)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.0),
            nonlin1 = cms.double(1.0),
            nonlin2 = cms.double(0.0),
            nonlin3 = cms.double(0.0),
            pixels = cms.int32(0)
        )
    ),
    hb = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.19),
        gainWidth = cms.vdouble(0.0),
        mcShape = cms.int32(125),
        pedestal = cms.double(3.285),
        pedestalWidth = cms.double(0.809),
        photoelectronsToAnalog = cms.double(0.3305),
        qieOffset = cms.vdouble(-0.49, 1.8, 7.2, 37.9),
        qieSlope = cms.vdouble(0.912, 0.917, 0.922, 0.923),
        qieType = cms.int32(0),
        recoShape = cms.int32(105),
        zsThreshold = cms.int32(8)
    ),
    hbUpgrade = cms.PSet(
        darkCurrent = cms.vdouble(0.01, 0.015),
        doRadiationDamage = cms.bool(True),
        gain = cms.vdouble(0.0006252),
        gainWidth = cms.vdouble(0),
        mcShape = cms.int32(206),
        pedestal = cms.double(17.3),
        pedestalWidth = cms.double(1.5),
        photoelectronsToAnalog = cms.double(40.0),
        qieOffset = cms.vdouble(0.0, 0.0, 0.0, 0.0),
        qieSlope = cms.vdouble(0.05376, 0.05376, 0.05376, 0.05376),
        qieType = cms.int32(2),
        radiationDamage = cms.PSet(
            depVsNeutrons = cms.vdouble(5.543e-10, 8.012e-10),
            depVsTemp = cms.double(0.0631),
            intlumiOffset = cms.double(150),
            intlumiToNeutrons = cms.double(367000000.0),
            temperatureBase = cms.double(20),
            temperatureNew = cms.double(-5)
        ),
        recoShape = cms.int32(206),
        zsThreshold = cms.int32(16)
    ),
    he = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.23),
        gainWidth = cms.vdouble(0),
        mcShape = cms.int32(125),
        pedestal = cms.double(3.163),
        pedestalWidth = cms.double(0.9698),
        photoelectronsToAnalog = cms.double(0.3305),
        qieOffset = cms.vdouble(-0.38, 2.0, 7.6, 39.6),
        qieSlope = cms.vdouble(0.912, 0.916, 0.92, 0.922),
        qieType = cms.int32(0),
        recoShape = cms.int32(105),
        zsThreshold = cms.int32(9)
    ),
    heUpgrade = cms.PSet(
        darkCurrent = cms.vdouble(0.01, 0.015),
        doRadiationDamage = cms.bool(True),
        gain = cms.vdouble(0.0006252),
        gainWidth = cms.vdouble(0),
        mcShape = cms.int32(206),
        pedestal = cms.double(17.3),
        pedestalWidth = cms.double(1.5),
        photoelectronsToAnalog = cms.double(40.0),
        qieOffset = cms.vdouble(0.0, 0.0, 0.0, 0.0),
        qieSlope = cms.vdouble(0.05376, 0.05376, 0.05376, 0.05376),
        qieType = cms.int32(2),
        radiationDamage = cms.PSet(
            depVsNeutrons = cms.vdouble(5.543e-10, 8.012e-10),
            depVsTemp = cms.double(0.0631),
            intlumiOffset = cms.double(75),
            intlumiToNeutrons = cms.double(29200000.0),
            temperatureBase = cms.double(20),
            temperatureNew = cms.double(5)
        ),
        recoShape = cms.int32(206),
        zsThreshold = cms.int32(16)
    ),
    hf = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.14, 0.135),
        gainWidth = cms.vdouble(0.0, 0.0),
        mcShape = cms.int32(301),
        pedestal = cms.double(9.354),
        pedestalWidth = cms.double(2.516),
        photoelectronsToAnalog = cms.double(0.0),
        qieOffset = cms.vdouble(-0.87, 1.4, 7.8, -29.6),
        qieSlope = cms.vdouble(0.359, 0.358, 0.36, 0.367),
        qieType = cms.int32(0),
        recoShape = cms.int32(301),
        zsThreshold = cms.int32(-9999)
    ),
    hfUpgrade = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.14, 0.135),
        gainWidth = cms.vdouble(0.0, 0.0),
        mcShape = cms.int32(301),
        pedestal = cms.double(13.33),
        pedestalWidth = cms.double(3.33),
        photoelectronsToAnalog = cms.double(0.0),
        qieOffset = cms.vdouble(0.0697, -0.7405, 12.38, -671.9),
        qieSlope = cms.vdouble(0.297, 0.298, 0.298, 0.313),
        qieType = cms.int32(1),
        recoShape = cms.int32(301),
        zsThreshold = cms.int32(-9999)
    ),
    ho = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.006, 0.0087),
        gainWidth = cms.vdouble(0.0, 0.0),
        mcShape = cms.int32(201),
        pedestal = cms.double(12.06),
        pedestalWidth = cms.double(0.6285),
        photoelectronsToAnalog = cms.double(4.0),
        qieOffset = cms.vdouble(-0.44, 1.4, 7.1, 38.5),
        qieSlope = cms.vdouble(0.907, 0.915, 0.92, 0.921),
        qieType = cms.int32(0),
        recoShape = cms.int32(201),
        zsThreshold = cms.int32(24)
    ),
    iLumi = cms.double(-1.0),
    killHE = cms.bool(False),
    testHEPlan1 = cms.bool(False),
    testHFQIE10 = cms.bool(False),
    toGet = cms.untracked.vstring('GainWidths'),
    useHBUpgrade = cms.bool(False),
    useHEUpgrade = cms.bool(False),
    useHFUpgrade = cms.bool(False),
    useHOUpgrade = cms.bool(True),
    useIeta18depth1 = cms.bool(True),
    useLayer0Weight = cms.bool(False)
)


process.jec = cms.ESSource("PoolDBESSource",
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        messageLevel = cms.untracked.int32(0),
        security = cms.untracked.string('')
    ),
    connect = cms.string('sqlite_fip:flashgg/Systematics/data/JEC/Summer19UL17_RunBCDEF_V5_DATA.db'),
    timetype = cms.string('runnumber'),
    toGet = cms.VPSet(cms.PSet(
        label = cms.untracked.string('AK4PFchs'),
        record = cms.string('JetCorrectionsRecord'),
        tag = cms.string('JetCorrectorParametersCollection_Summer19UL17_RunBCDEF_V5_DATA_AK4PFchs')
    ))
)


process.jer = cms.ESSource("PoolDBESSource",
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        messageLevel = cms.untracked.int32(0),
        security = cms.untracked.string('')
    ),
    connect = cms.string('sqlite_fip:flashgg/Systematics/data/JER/Summer19UL17_JRV2_DATA.db'),
    toGet = cms.VPSet(
        cms.PSet(
            label = cms.untracked.string('AK4PFchs_pt'),
            record = cms.string('JetResolutionRcd'),
            tag = cms.string('JR_Summer19UL17_JRV2_DATA_PtResolution_AK4PFchs')
        ), 
        cms.PSet(
            label = cms.untracked.string('AK4PFchs'),
            record = cms.string('JetResolutionScaleFactorRcd'),
            tag = cms.string('JR_Summer19UL17_JRV2_DATA_SF_AK4PFchs')
        )
    )
)


process.prefer("es_hardcode")

process.prefer("jec")

process.prefer("jer")

process.ak4CaloL2L3ResidualCorrectorTask = cms.Task(process.ak4CaloL2L3ResidualCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloResidualCorrector)


process.ak4PFCHSL2L3ResidualCorrectorTask = cms.Task(process.ak4PFCHSL2L3ResidualCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector, process.ak4PFCHSResidualCorrector)


process.ak4CaloL1L2L3ResidualCorrectorTask = cms.Task(process.ak4CaloL1L2L3ResidualCorrector, process.ak4CaloL1OffsetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloResidualCorrector)


process.ak4PFPuppiL1L2L3ResidualCorrectorTask = cms.Task(process.ak4PFPuppiL1L2L3ResidualCorrector, process.ak4PFPuppiL1OffsetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector, process.ak4PFPuppiResidualCorrector)


process.ak4L1JPTOffsetCorrectorTask = cms.Task(process.ak4CaloL1OffsetCorrector, process.ak4L1JPTOffsetCorrector)


process.ak4JPTL1L2L3ResidualCorrectorTask = cms.Task(process.ak4JPTL1L2L3ResidualCorrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4JPTResidualCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4PFL1L2L3CorrectorTask = cms.Task(process.ak4PFL1L2L3Corrector, process.ak4PFL1OffsetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector)


process.ak4CaloL1L2L3CorrectorTask = cms.Task(process.ak4CaloL1L2L3Corrector, process.ak4CaloL1OffsetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector)


process.ak4CaloL1FastL2L3CorrectorTask = cms.Task(process.ak4CaloL1FastL2L3Corrector, process.ak4CaloL1FastjetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector)


process.ak4PFPuppiL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4PFPuppiL1FastL2L3ResidualCorrector, process.ak4PFPuppiL1FastjetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector, process.ak4PFPuppiResidualCorrector)


process.ak4CaloL2L3L6CorrectorTask = cms.Task(process.ak4CaloL2L3L6Corrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloL6SLBCorrector)


process.ak4L1JPTFastjetCorrectorTask = cms.Task(process.ak4CaloL1FastjetCorrector, process.ak4L1JPTFastjetCorrector)


process.ak4PFL1FastL2L3CorrectorTask = cms.Task(process.ak4PFL1FastL2L3Corrector, process.ak4PFL1FastjetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector)


process.ak4TrackL2L3CorrectorTask = cms.Task(process.ak4TrackL2L3Corrector, process.ak4TrackL2RelativeCorrector, process.ak4TrackL3AbsoluteCorrector)


process.ak4PFL2L3L6CorrectorTask = cms.Task(process.ak4PFL2L3L6Corrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFL6SLBCorrector)


process.ak4JPTL2L3ResidualCorrectorTask = cms.Task(process.ak4JPTL2L3ResidualCorrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4JPTResidualCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4JPTL2L3CorrectorTask = cms.Task(process.ak4JPTL2L3Corrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4PFPuppiL1FastL2L3CorrectorTask = cms.Task(process.ak4PFPuppiL1FastL2L3Corrector, process.ak4PFPuppiL1FastjetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector)


process.ak4PFPuppiL1L2L3CorrectorTask = cms.Task(process.ak4PFPuppiL1L2L3Corrector, process.ak4PFPuppiL1OffsetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector)


process.ak4PFL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4PFL1FastL2L3ResidualCorrector, process.ak4PFL1FastjetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFResidualCorrector)


process.ak4CaloL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4CaloL1FastL2L3ResidualCorrector, process.ak4CaloL1FastjetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloResidualCorrector)


process.ak4PFCHSL1FastL2L3CorrectorTask = cms.Task(process.ak4PFCHSL1FastL2L3Corrector, process.ak4PFCHSL1FastjetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector)


process.ak4PFL1L2L3ResidualCorrectorTask = cms.Task(process.ak4PFL1L2L3ResidualCorrector, process.ak4PFL1OffsetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFResidualCorrector)


process.ak4PFL2L3ResidualCorrectorTask = cms.Task(process.ak4PFL2L3ResidualCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFResidualCorrector)


process.ak4JPTL1L2L3CorrectorTask = cms.Task(process.ak4JPTL1L2L3Corrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4PFCHSL2L3CorrectorTask = cms.Task(process.ak4PFCHSL2L3Corrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector)


process.ak4CaloL2L3CorrectorTask = cms.Task(process.ak4CaloL2L3Corrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector)


process.ak4PFL1FastL2L3L6CorrectorTask = cms.Task(process.ak4PFL1FastL2L3L6Corrector, process.ak4PFL1FastjetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFL6SLBCorrector)


process.ak4PFCHSL1L2L3CorrectorTask = cms.Task(process.ak4PFCHSL1L2L3Corrector, process.ak4PFCHSL1OffsetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector)


process.ak4PFCHSL1L2L3ResidualCorrectorTask = cms.Task(process.ak4PFCHSL1L2L3ResidualCorrector, process.ak4PFCHSL1OffsetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector, process.ak4PFCHSResidualCorrector)


process.ak4PFPuppiL2L3ResidualCorrectorTask = cms.Task(process.ak4PFPuppiL2L3ResidualCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector, process.ak4PFPuppiResidualCorrector)


process.ak4PFPuppiL2L3CorrectorTask = cms.Task(process.ak4PFPuppiL2L3Corrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector)


process.ak4JPTL1FastL2L3CorrectorTask = cms.Task(process.ak4JPTL1FastL2L3Corrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4L1JPTFastjetCorrectorTask)


process.ak4PFCHSL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4PFCHSL1FastL2L3ResidualCorrector, process.ak4PFCHSL1FastjetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector, process.ak4PFCHSResidualCorrector)


process.ak4PFL2L3CorrectorTask = cms.Task(process.ak4PFL2L3Corrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector)


process.ak4CaloL1FastL2L3L6CorrectorTask = cms.Task(process.ak4CaloL1FastL2L3L6Corrector, process.ak4CaloL1FastjetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloL6SLBCorrector)


process.ak4JPTL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4JPTL1FastL2L3ResidualCorrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4JPTResidualCorrector, process.ak4L1JPTFastjetCorrectorTask)


process.jetCorrectorsTask = cms.Task(process.ak4CaloL1FastL2L3CorrectorTask, process.ak4CaloL1FastL2L3L6CorrectorTask, process.ak4CaloL1FastL2L3ResidualCorrectorTask, process.ak4CaloL1L2L3CorrectorTask, process.ak4CaloL1L2L3ResidualCorrectorTask, process.ak4CaloL2L3CorrectorTask, process.ak4CaloL2L3L6CorrectorTask, process.ak4CaloL2L3ResidualCorrectorTask, process.ak4JPTL1FastL2L3CorrectorTask, process.ak4JPTL1FastL2L3ResidualCorrectorTask, process.ak4JPTL1L2L3CorrectorTask, process.ak4JPTL1L2L3ResidualCorrectorTask, process.ak4JPTL2L3CorrectorTask, process.ak4JPTL2L3ResidualCorrectorTask, process.ak4L1JPTFastjetCorrectorTask, process.ak4L1JPTOffsetCorrectorTask, process.ak4PFCHSL1FastL2L3CorrectorTask, process.ak4PFCHSL1FastL2L3ResidualCorrectorTask, process.ak4PFCHSL1L2L3CorrectorTask, process.ak4PFCHSL1L2L3ResidualCorrectorTask, process.ak4PFCHSL2L3CorrectorTask, process.ak4PFCHSL2L3ResidualCorrectorTask, process.ak4PFL1FastL2L3CorrectorTask, process.ak4PFL1FastL2L3L6CorrectorTask, process.ak4PFL1FastL2L3ResidualCorrectorTask, process.ak4PFL1L2L3CorrectorTask, process.ak4PFL1L2L3ResidualCorrectorTask, process.ak4PFL2L3CorrectorTask, process.ak4PFL2L3L6CorrectorTask, process.ak4PFL2L3ResidualCorrectorTask, process.ak4PFPuppiL1FastL2L3CorrectorTask, process.ak4PFPuppiL1FastL2L3ResidualCorrectorTask, process.ak4PFPuppiL1L2L3CorrectorTask, process.ak4PFPuppiL1L2L3ResidualCorrectorTask, process.ak4PFPuppiL2L3CorrectorTask, process.ak4PFPuppiL2L3ResidualCorrectorTask, process.ak4TrackL2L3CorrectorTask)


process.ak4JPTL2L3ResidualCorrectorChain = cms.Sequence(process.ak4JPTL2L3ResidualCorrectorTask)


process.ak4PFL1FastL2L3L6CorrectorChain = cms.Sequence(process.ak4PFL1FastL2L3L6CorrectorTask)


process.ak4L1JPTOffsetCorrectorChain = cms.Sequence(process.ak4L1JPTOffsetCorrectorTask)


process.ak4TrackL2L3CorrectorChain = cms.Sequence(process.ak4TrackL2L3CorrectorTask)


process.ak4PFPuppiL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFPuppiL2L3ResidualCorrectorTask)


process.flashggTagSequence = cms.Sequence(process.flashggPrefireDiPhotons+process.flashggPreselectedDiPhotons+process.flashggDiPhotonMVA+process.flashggVBFMVA+process.flashggVHhadMVA+process.flashggGluGluHMVA+process.flashggStageOneCombinedTag+process.flashggTHQLeptonicTag+process.flashggVHMetTag+process.flashggWHLeptonicTag+process.flashggZHLeptonicTag+process.flashggTagSorter)


process.ak4JPTL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4JPTL1FastL2L3ResidualCorrectorTask)


process.ak4PFL2L3L6CorrectorChain = cms.Sequence(process.ak4PFL2L3L6CorrectorTask)


process.ak4PFL1L2L3CorrectorChain = cms.Sequence(process.ak4PFL1L2L3CorrectorTask)


process.ak4PFCHSL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFCHSL1FastL2L3ResidualCorrectorTask)


process.ak4PFCHSL1FastL2L3CorrectorChain = cms.Sequence(process.ak4PFCHSL1FastL2L3CorrectorTask)


process.ak4CaloL1L2L3CorrectorChain = cms.Sequence(process.ak4CaloL1L2L3CorrectorTask)


process.finalFilter = cms.Sequence()


process.ak4PFCHSL1L2L3CorrectorChain = cms.Sequence(process.ak4PFCHSL1L2L3CorrectorTask)


process.genFilter = cms.Sequence()


process.ak4CaloL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4CaloL1FastL2L3ResidualCorrectorTask)


process.ak4PFL1FastL2L3CorrectorChain = cms.Sequence(process.ak4PFL1FastL2L3CorrectorTask)


process.jetCorrectorChain = cms.Sequence(process.ak4PFCHSL1FastL2L3ResidualCorrectorChain)


process.ak4CaloL2L3L6CorrectorChain = cms.Sequence(process.ak4CaloL2L3L6CorrectorTask)


process.penultimateFilter = cms.Sequence()


process.ak4JPTL2L3CorrectorChain = cms.Sequence(process.ak4JPTL2L3CorrectorTask)


process.ak4CaloL2L3CorrectorChain = cms.Sequence(process.ak4CaloL2L3CorrectorTask)


process.ak4JPTL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4JPTL1L2L3ResidualCorrectorTask)


process.ak4PFPuppiL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFPuppiL1L2L3ResidualCorrectorTask)


process.ak4PFPuppiL1FastL2L3CorrectorChain = cms.Sequence(process.ak4PFPuppiL1FastL2L3CorrectorTask)


process.ak4PFL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFL1FastL2L3ResidualCorrectorTask)


process.extraDumpers = cms.Sequence()


process.ak4L1JPTFastjetCorrectorChain = cms.Sequence(process.ak4L1JPTFastjetCorrectorTask)


process.ak4JPTL1L2L3CorrectorChain = cms.Sequence(process.ak4JPTL1L2L3CorrectorTask)


process.ak4PFPuppiL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFPuppiL1FastL2L3ResidualCorrectorTask)


process.ak4PFCHSL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFCHSL2L3ResidualCorrectorTask)


process.dataRequirements = cms.Sequence(process.hltHighLevel)


process.jetSystematicsSequence = cms.Sequence(process.jetCorrectorChain+process.flashggJetSystematics0+process.flashggJetSystematics1+process.flashggJetSystematics2+process.flashggJetSystematics3+process.flashggJetSystematics4+process.flashggJetSystematics5+process.flashggJetSystematics6+process.flashggJetSystematics7+process.flashggJetSystematics8+process.flashggJetSystematics9+process.flashggJetSystematics10+process.flashggJetSystematics11)


process.systematicsTagSequences = cms.Sequence()


process.ak4CaloL1FastL2L3L6CorrectorChain = cms.Sequence(process.ak4CaloL1FastL2L3L6CorrectorTask)


process.ak4PFL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFL2L3ResidualCorrectorTask)


process.ak4PFCHSL2L3CorrectorChain = cms.Sequence(process.ak4PFCHSL2L3CorrectorTask)


process.ak4PFPuppiL1L2L3CorrectorChain = cms.Sequence(process.ak4PFPuppiL1L2L3CorrectorTask)


process.ak4CaloL2L3ResidualCorrectorChain = cms.Sequence(process.ak4CaloL2L3ResidualCorrectorTask)


process.ak4PFCHSL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFCHSL1L2L3ResidualCorrectorTask)


process.ak4PFL2L3CorrectorChain = cms.Sequence(process.ak4PFL2L3CorrectorTask)


process.ak4CaloL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4CaloL1L2L3ResidualCorrectorTask)


process.ak4CaloL1FastL2L3CorrectorChain = cms.Sequence(process.ak4CaloL1FastL2L3CorrectorTask)


process.ak4PFPuppiL2L3CorrectorChain = cms.Sequence(process.ak4PFPuppiL2L3CorrectorTask)


process.ak4JPTL1FastL2L3CorrectorChain = cms.Sequence(process.ak4JPTL1FastL2L3CorrectorTask)


process.ak4PFL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFL1L2L3ResidualCorrectorTask)


process.p = cms.Path(process.dataRequirements+process.flashggMetFilters+process.genFilter+process.flashggDifferentialPhoIdInputsCorrection+process.flashggDiPhotonSystematics+process.flashggMetSystematics+process.flashggMuonSystematics+process.flashggElectronSystematics+process.flashggUnpackedJets+process.jetSystematicsSequence+process.flashggPrefireDiPhotons+process.flashggPreselectedDiPhotons+process.flashggDiPhotonMVA+process.flashggVBFMVA+process.flashggVHhadMVA+process.flashggGluGluHMVA+process.flashggStageOneCombinedTag+process.flashggTHQLeptonicTag+process.flashggVHMetTag+process.flashggWHLeptonicTag+process.flashggZHLeptonicTag+process.systematicsTagSequences+(process.flashggTTHLeptonicTag+process.flashggTTHHadronicTag)+process.flashggTagSorter+process.flashggSystTagMerger+process.penultimateFilter+process.finalFilter+process.tagsDumper)


